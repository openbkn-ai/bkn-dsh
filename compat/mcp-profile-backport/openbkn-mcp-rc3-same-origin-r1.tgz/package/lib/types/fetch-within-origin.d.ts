/**
 * Extracted from modelcontextprotocol/typescript-sdk 433eb413dc305ebeb93b8ebcde0095a8fc0d5fa0.
 * Upstream license notice is retained in MCP-SDK-LICENSE.txt.
 * Only the unused unsafe opt-out registry is omitted.
 * A private Host backport proposal, not an installed runtime change.
 */
type FetchLike = (url: string | URL, init?: RequestInit) => Promise<Response>;
/** Whether `to` has the scheme, host and port of `from`, or is its https form with both on the default port. */
export declare function isWithinOrigin(from: URL, to: URL): boolean;
/** Wraps `baseFetch` to follow a redirect only when it keeps the method and stays within the origin of the request. */
export declare function fetchWithinOrigin(baseFetch: FetchLike): FetchLike;
export {};
