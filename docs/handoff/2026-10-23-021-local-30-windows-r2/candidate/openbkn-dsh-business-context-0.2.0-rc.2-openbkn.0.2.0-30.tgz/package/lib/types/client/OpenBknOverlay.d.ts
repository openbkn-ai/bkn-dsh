import type { InjectFace, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { OpenBknUiController } from './openbkn-ui-controller.ts';
import type { OpenBknConfigurationInput } from '../types.ts';
import type { CliSetupPort } from './cli-setup-controller.ts';
export interface OpenBknOverlayInjected {
    hooks: {
        ui: OpenBknUiController;
    };
    close(): void;
    refresh(): Promise<void>;
    cancelLogin(): void;
    beginLogin(): Promise<void>;
    showSettings(): Promise<void>;
    saveConfiguration(input: OpenBknConfigurationInput): Promise<void>;
    cliSetup: CliSetupPort;
    openNetwork(networkId: string, mode: 'continue' | 'new' | 'create-workspace'): Promise<void>;
    openDiagnostics(): void;
}
export type OpenBknOverlayProps = PropsRuntime<'shell.overlay'> & InjectFace<OpenBknOverlayInjected>;
/** Frame-wide, additive OpenBKN control plane. It is intentionally outside DSH chat scroll containers. */
export declare function OpenBknOverlay({ useUi, close, refresh, beginLogin, cancelLogin, showSettings, saveConfiguration, cliSetup, openNetwork, openDiagnostics }: OpenBknOverlayProps): import("react").JSX.Element | null;
//# sourceMappingURL=OpenBknOverlay.d.ts.map