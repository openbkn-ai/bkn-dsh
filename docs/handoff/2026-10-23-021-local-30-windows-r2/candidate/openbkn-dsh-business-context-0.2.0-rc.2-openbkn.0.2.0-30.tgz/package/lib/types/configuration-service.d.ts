/** Profile settings bridge owned by the independent diagnostics row. */
import { Context } from '@deepseek-ai/cordis';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import type { OpenBknCliInstallVersion, OpenBknCliSetupView, OpenBknConfigurationInput, OpenBknConfigurationView } from './types.js';
declare module '@deepseek-ai/cordis' {
    interface Context {
        openbknConfiguration: OpenBknConfigurationService;
    }
}
declare module '@deepseek-ai/dsh-typert-protocol' {
    interface RemoteErrorDetailsMap {
        'openbkn/configuration-invalid': {
            readonly configField: 'baseUrl' | 'cliPath';
        };
        'openbkn/configuration-unavailable': {
            readonly reason: string;
        };
        'openbkn/configuration-busy': Record<string, never>;
        'openbkn/configuration-save-failed': Record<string, never>;
    }
}
/** Keep all writes in the host's editor; never write YAML or credentials here. */
export declare class OpenBknConfigurationService extends TypertRemoteService {
    private saving;
    private cliSetup?;
    /** A short admission fence while the native editor writes/reloads. */
    get isChanging(): boolean;
    constructor(ctx: Context);
    private setup;
    checkCli(cliPath: string, signal?: AbortSignal): Promise<OpenBknCliSetupView>;
    installCli(cliPath: string, targetVersion?: OpenBknCliInstallVersion): Promise<OpenBknCliSetupView>;
    private editor;
    private entry;
    private observedEntry;
    private busy;
    getConfiguration(signal?: AbortSignal): Promise<OpenBknConfigurationView>;
    saveConfiguration(input: OpenBknConfigurationInput, signal?: AbortSignal): Promise<OpenBknConfigurationView>;
}
//# sourceMappingURL=configuration-service.d.ts.map