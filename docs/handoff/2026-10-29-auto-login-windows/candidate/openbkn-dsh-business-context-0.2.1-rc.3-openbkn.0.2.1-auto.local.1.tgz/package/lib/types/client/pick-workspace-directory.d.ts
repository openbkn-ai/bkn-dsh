import type { UiWorkspace } from '@deepseek-ai/dsh-client-ui-workspace/client';
/** Use the same origin-scoped Desktop picker as the native workspace flow. */
export declare function pickWorkspaceDirectory(workspace: Pick<UiWorkspace, 'pickDirectory'>, desktop?: unknown): Promise<string | null>;
//# sourceMappingURL=pick-workspace-directory.d.ts.map