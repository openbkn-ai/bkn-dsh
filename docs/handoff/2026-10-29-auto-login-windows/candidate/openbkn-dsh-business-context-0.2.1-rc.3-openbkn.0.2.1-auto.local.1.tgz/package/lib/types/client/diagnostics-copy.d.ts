import type { OpenBknTranslate } from './messages.ts';
export declare function diagnosticAction(text: string, t: OpenBknTranslate): string;
//# sourceMappingURL=diagnostics-copy.d.ts.map