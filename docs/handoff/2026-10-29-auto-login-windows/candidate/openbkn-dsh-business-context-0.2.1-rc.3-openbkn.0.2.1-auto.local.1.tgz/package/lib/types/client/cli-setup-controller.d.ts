import { type OpenBknTranslate } from './messages.ts';
import type { OpenBknCliInstallVersion, OpenBknCliSetupView } from '../types.ts';
export interface CliSetupPort {
    checkCli(cliPath: string, signal?: AbortSignal): Promise<OpenBknCliSetupView>;
    installCli(cliPath: string, targetVersion: OpenBknCliInstallVersion): Promise<OpenBknCliSetupView>;
}
export interface CliSetupState {
    readonly phase: 'idle' | 'checking' | OpenBknCliSetupView['state'];
    readonly result?: OpenBknCliSetupView;
    readonly setupRequested?: boolean;
}
/** Read-only checks are cancellable; an accepted Host installation survives panel closure. */
export declare class CliSetupController {
    private readonly port;
    private readonly resolved;
    private state;
    private revision;
    private disposed;
    private clicking;
    private reading?;
    private timer?;
    private readonly listeners;
    constructor(port: CliSetupPort, resolved: (path: string) => void);
    snapshot(): CliSetupState;
    subscribe(listener: () => void): () => void;
    check(cliPath: string): Promise<void>;
    detectAndInstall(cliPath: string, targetVersion?: OpenBknCliInstallVersion): Promise<void>;
    dispose(): void;
    private inspect;
    private accept;
    private current;
    private publish;
}
/** Only controlled reasons become user-facing text; raw installer output stays on Host. */
export declare function cliSetupMessage(state: CliSetupState, savedCliPath?: string, targetVersion?: OpenBknCliInstallVersion, t?: OpenBknTranslate): string;
//# sourceMappingURL=cli-setup-controller.d.ts.map