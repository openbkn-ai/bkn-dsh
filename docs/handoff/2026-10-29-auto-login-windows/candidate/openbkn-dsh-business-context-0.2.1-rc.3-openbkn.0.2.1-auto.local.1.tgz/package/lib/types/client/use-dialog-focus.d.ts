/** Keep keyboard interaction inside an open modal and return it to its opener. */
export declare function useDialogFocus(open: boolean, close: () => void): import("react").RefObject<HTMLElement>;
//# sourceMappingURL=use-dialog-focus.d.ts.map