import { type ToolExecution, type ToolExecutionResult } from '@deepseek-ai/dsh-tools';
import type { Agent } from '@deepseek-ai/dsh-agent';
import type { BusinessNetworkBinding } from './types.js';
export declare const CSV_EXPORT_TOOL = "openbkn_export_csv";
export declare const MAX_CSV_BYTES: number;
interface Identity {
    readonly conversationId: string;
    readonly interactionId: string;
}
interface WorkingDirectory {
    ensure(agent: Agent, signal?: AbortSignal): Promise<string>;
}
interface Target {
    readonly displayPath: string;
}
interface FilePolicy {
    readonly mode: 'read-only' | 'workspace-write' | 'danger-full-access';
    readonly workspaceRoot: string;
    readonly sessionId?: string;
}
/** Native Host filesystem ports; no Node filesystem bypass or caller-chosen destination. */
export interface CsvExportHost {
    readonly workingDirectory: WorkingDirectory;
    readonly sandboxPolicy: {
        resolve(request: {
            session: Agent['session'];
        }): FilePolicy;
    };
    readonly fs: {
        resolve(path: string, options?: {
            cwd?: string;
            signal?: AbortSignal;
        }): Promise<Target>;
        contains(parent: Target, child: Target): boolean;
        processPath(target: Target): string;
        writeText(target: Target, text: string, expected: {
            kind: 'createIfAbsent';
        }, signal: AbortSignal, policy: FilePolicy): Promise<unknown>;
        readBytes(target: Target, signal: AbortSignal, maxBytes: number): Promise<Uint8Array>;
    };
    readonly tools: {
        get(name: string, agent?: object): unknown;
        execute(input: {
            callId: ToolExecution['callId'];
            rootCallId?: ToolExecution['rootCallId'];
            parent?: ToolExecution['token'];
            name: string;
            arguments: unknown;
            agent: Agent;
            signal: AbortSignal;
        }): Promise<ToolExecutionResult>;
    };
}
/** An optional native service is absent on unsupported presets; never fall back to local Node I/O. */
export declare function csvExportHost(context: unknown, currentDirectory?: () => WorkingDirectory | undefined): CsvExportHost | undefined;
export declare function validateCsvPath(value: string): string;
/**
 * Read bytes through the already-managed platform executor. Descriptor walking
 * refuses symlinks and special files, even when a model-created path races the
 * read. No session enumeration, credentials, raw HTTP, or business calculation.
 */
export declare function csvReadCode(path: string, conversationId: string): string;
export declare function decodeCsvResult(result: ToolExecutionResult, path: string): {
    bytes: Buffer;
    sha256: string;
};
/** Only a model-invoked, scoped delivery operation; it never edits an answer. */
export declare function createCsvExportTool(host: CsvExportHost, binding: BusinessNetworkBinding, owner: Agent, activeIdentity: () => Identity | undefined): import("@deepseek-ai/dsh-tools").ToolDefinition;
export {};
//# sourceMappingURL=platform-csv-export.d.ts.map