import { type UiMessage } from './messages.ts';
import type { AuthSnapshot, BusinessNetworkBinding, BusinessNetworkSummary, OpenBknConfigurationInput, OpenBknConfigurationView } from '../types.ts';
/** Minimal browser-safe port over the generated OpenBKN Remote contract. */
export interface OpenBknUiPort {
    status(signal?: AbortSignal): Promise<AuthSnapshot>;
    beginLogin(signal?: AbortSignal): Promise<readonly BusinessNetworkSummary[]>;
    configureToken(token: string, signal?: AbortSignal): Promise<readonly BusinessNetworkSummary[]>;
    listNetworks(signal?: AbortSignal): Promise<readonly BusinessNetworkSummary[]>;
    bindNetworkWorkspace(networkId: string, workspacePath: string, signal?: AbortSignal): Promise<BusinessNetworkSummary>;
    bindNetwork(sessionId: string, networkId: string, signal?: AbortSignal): Promise<BusinessNetworkBinding>;
}
export type NetworkSessionMode = 'continue' | 'new' | 'create-workspace';
export type OpenNetworkSession = (network: BusinessNetworkSummary, mode: NetworkSessionMode, signal?: AbortSignal) => Promise<string>;
/** Independent from the business row, so first-use configuration can reload it safely. */
export interface OpenBknConfigurationPort {
    getConfiguration(signal?: AbortSignal): Promise<OpenBknConfigurationView>;
    saveConfiguration(input: OpenBknConfigurationInput, signal?: AbortSignal): Promise<OpenBknConfigurationView>;
}
export type OpenBknOverlayPhase = 'idle' | 'loading' | 'authentication-required' | 'ready' | 'binding' | 'configuration' | 'error';
/** Render state for the additive OpenBKN overlay; credentials never enter it. */
export interface OpenBknOverlayState {
    readonly open: boolean;
    readonly login?: 'waiting' | 'succeeded' | 'failed' | 'timed-out' | 'cancelled';
    readonly phase: OpenBknOverlayPhase;
    readonly auth?: AuthSnapshot;
    readonly networks: readonly BusinessNetworkSummary[];
    readonly message?: UiMessage;
    readonly configuration?: OpenBknConfigurationView;
    readonly configurationMessage?: UiMessage;
    readonly savingConfiguration?: boolean;
    readonly loadingConfiguration?: boolean;
}
type Listener = () => void;
/**
 * Keeps Remote calls and their transient UI state outside React components.
 * The controller intentionally knows only a selected session ID and safe
 * catalogue summaries; Host code remains authoritative for authentication,
 * visibility and durable binding.
 */
export declare class OpenBknUiController {
    private readonly port;
    private readonly openNetworkSession;
    private readonly refreshBoundSession?;
    private readonly configurationPort?;
    private readonly loginTimeoutMs;
    private state;
    private readonly listeners;
    private revision;
    private operation?;
    private loginTimer?;
    constructor(port: OpenBknUiPort, openNetworkSession: OpenNetworkSession, refreshBoundSession?: ((sessionId: string) => void) | undefined, configurationPort?: OpenBknConfigurationPort | undefined, loginTimeoutMs?: number);
    snapshot(): OpenBknOverlayState;
    getSnapshot(): OpenBknOverlayState;
    subscribe(listener: Listener): () => void;
    open(): void;
    close(): void;
    /** A business-row reload must not invalidate its independent configuration save. */
    businessChanged(): void;
    refresh(signal?: AbortSignal): Promise<void>;
    showSettings(): Promise<void>;
    saveConfiguration(input: OpenBknConfigurationInput): Promise<void>;
    /** Existing internal API; deliberately absent from the ordinary user interface. */
    configureToken(token: string): Promise<void>;
    beginLogin(signal?: AbortSignal): Promise<void>;
    cancelLogin(): void;
    private finishLoginWait;
    openNetwork(networkId: string, mode: NetworkSessionMode, signal?: AbortSignal): Promise<void>;
    private loadBusiness;
    private connectionFailed;
    private start;
    private current;
    private invalidate;
    private publish;
}
/**
 * Classify a failed `uiWorkspace.pickDirectory()`. DSH rewraps the Host's
 * `directory-picker/unavailable` refusal into a plain message, so the browse
 * backend (remote/SSH hosts) is recognised by that message; any other failure
 * is the native chooser itself failing and keeps its own text.
 */
export declare function directoryPickerFailure(error: unknown): Error;
/** The operator dismissed the workspace directory chooser. */
export declare function workspaceSelectionCancelled(): Error;
export {};
//# sourceMappingURL=openbkn-ui-controller.d.ts.map