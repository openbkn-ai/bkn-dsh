import { type OpenBknTranslate } from './messages.ts';
import type { DiagnosticsTarget } from '../diagnostics-contract.ts';
/** Presentation only: keep raw report facts and missing values unchanged. */
export declare function diagnosticsTargetRows(target: DiagnosticsTarget, t?: OpenBknTranslate): readonly {
    label: string;
    value: string;
}[];
//# sourceMappingURL=diagnostics-target.d.ts.map