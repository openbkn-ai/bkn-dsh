import { type CliSetupPort } from './cli-setup-controller.ts';
export declare function CliSetupControl({ cliPath, savedCliPath, disabled, port, onResolved, onBusy }: {
    cliPath: string;
    savedCliPath: string;
    disabled: boolean;
    port: CliSetupPort;
    onResolved(path: string): void;
    onBusy(busy: boolean, lockPath: boolean): void;
}): import("react").JSX.Element;
//# sourceMappingURL=CliSetupControl.d.ts.map