import type { CertificateIdentity, OpenBknConfigurationInput, PlatformCertificatePreview } from '../types.js';
export type CertificateChoice = Pick<OpenBknConfigurationInput, 'trustConfirmationId' | 'removeCertificate'>;
export interface CertificatePort {
    previewCertificate(baseUrl: string, pem: string): Promise<PlatformCertificatePreview>;
}
/** File contents are previewed in the Host; no path or certificate is persisted in browser state. */
export declare function CertificateControl({ baseUrl, current, certificateError, disabled, port, onChange }: {
    baseUrl: string;
    current?: CertificateIdentity;
    certificateError?: string;
    disabled: boolean;
    port?: CertificatePort;
    onChange(choice: CertificateChoice, pending: boolean): void;
}): import("react").JSX.Element;
//# sourceMappingURL=CertificateControl.d.ts.map