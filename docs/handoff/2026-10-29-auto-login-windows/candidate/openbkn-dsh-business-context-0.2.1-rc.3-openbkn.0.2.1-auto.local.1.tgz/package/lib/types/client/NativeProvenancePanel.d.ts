import type { ProvenanceView } from '../types.ts';
type Tab = 'events' | 'evidence';
/** Relationships are selected by disclosed identifiers only; no text, value or temporal matching. */
export declare function NativeProvenancePanel({ view, tab, onTabChange }: {
    view: ProvenanceView;
    tab: Tab;
    onTabChange?: (tab: Tab) => void;
}): import("react").JSX.Element;
export {};
//# sourceMappingURL=NativeProvenancePanel.d.ts.map