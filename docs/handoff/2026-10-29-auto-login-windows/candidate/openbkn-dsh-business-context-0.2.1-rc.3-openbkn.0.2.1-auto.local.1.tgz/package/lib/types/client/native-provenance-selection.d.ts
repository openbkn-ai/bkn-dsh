import type { NativeBusinessFunction, NativeChainNode, NativeClaim, NativeExplanation, NativePairGraph, NativeTimeItem } from '../native-provenance-types.ts';
export type NativeTargetKind = 'claim' | 'evidence' | 'schema' | 'execution' | 'step' | 'event' | 'function';
export interface NativeTarget {
    kind: NativeTargetKind;
    id: string;
}
export declare const targetKey: (target: NativeTarget) => string;
/** A display-only index of disclosed dependencies, scoped to the selected question pair. */
export declare function nativeSelectionModel(explanation: NativeExplanation | undefined, pairId: string | undefined, rail: readonly NativeTimeItem[]): {
    pair: {
        id: string;
        question: string;
        answer: string;
        summary: string;
        status: string;
        reasonCode?: string;
        claimIds: string[];
    } | undefined;
    graph: NativePairGraph | undefined;
    claims: NativeClaim[];
    evidence: NativeChainNode[];
    schema: NativeChainNode[];
    execution: NativeChainNode[];
    steps: {
        id: string;
        operationId: string;
        attempt: number;
        businessRole: string;
        interfaceName: string;
        status: string;
        timeRailItemId: string;
    }[];
    functions: NativeBusinessFunction[];
    events: readonly NativeTimeItem[];
    resolve: (id: string, kinds?: readonly NativeTargetKind[]) => NativeTarget | undefined;
    resolveSchemaRef: (id: string) => NativeTarget | undefined;
    operationTargets: (id: string) => NativeTarget[];
    inputSourceTargets: (input: NativeBusinessFunction["businessInputs"][number]) => NativeTarget[];
    selection: (requested?: NativeTarget) => {
        active: NativeTarget | undefined;
        related: Set<string>;
        isRelated: (target: NativeTarget) => boolean;
        isSelected: (target: NativeTarget) => boolean;
    };
    node: (target: NativeTarget | undefined) => NativeChainNode | undefined;
    unresolved: Set<string>;
};
//# sourceMappingURL=native-provenance-selection.d.ts.map