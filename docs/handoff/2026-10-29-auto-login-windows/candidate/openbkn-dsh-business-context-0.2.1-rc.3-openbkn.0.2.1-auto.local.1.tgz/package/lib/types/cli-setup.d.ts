import type { CliSubprocess } from './openbkn-cli-subprocess.js';
import type { OpenBknCliInstallVersion, OpenBknCliSetupView } from './types.js';
export declare const CLI_INSTALL_VERSION = "0.1.5";
export declare function isCliInstallVersion(value: unknown): value is OpenBknCliInstallVersion;
interface SetupEnvironment {
    readonly platform: NodeJS.Platform;
    readonly home: string;
    readonly env: Readonly<Record<string, string | undefined>>;
    readonly exists: (file: string) => Promise<boolean>;
    readonly isDirectory: (file: string) => Promise<boolean>;
}
/** One Host-owned installation at a time; closing a browser panel cannot kill npm halfway. */
export declare class OpenBknCliSetup {
    private readonly subprocess;
    private readonly cwd;
    private readonly environment;
    private installation?;
    private targetVersion?;
    private readonly lifetime;
    constructor(subprocess: CliSubprocess, cwd: string, environment?: SetupEnvironment);
    dispose(): void;
    get isInstalling(): boolean;
    check(cliPath: string, signal?: AbortSignal): Promise<OpenBknCliSetupView>;
    /** Called only from the explicit product button, never during initial detection. */
    install(cliPath: string, targetVersion?: OpenBknCliInstallVersion): Promise<OpenBknCliSetupView>;
    private performInstall;
    private inspect;
    private verify;
    private paths;
    private binaryAt;
    private standardCandidates;
    private run;
}
export {};
//# sourceMappingURL=cli-setup.d.ts.map