import type { NativeExplanationResult, NativeInteractionDetail } from './native-provenance-types.js';
export declare const NATIVE_PROVENANCE_LIMITS: {
    readonly wireBytes: number;
    readonly dtoBytes: 1000000;
    readonly nodes: 500;
    readonly edges: 1000;
    readonly getTimeoutMs: 30000;
};
export declare class NativeProjectionError extends Error {
    readonly reason: 'invalid-response' | 'result-too-large';
    constructor(reason: 'invalid-response' | 'result-too-large');
}
export declare function projectNativeExplanation(value: unknown, interactionId: string, maxBytes?: number): Exclude<NativeExplanationResult, {
    kind: 'unavailable';
}>;
export declare function projectNativeDetail(value: unknown, interactionId: string, maxBytes?: number): NativeInteractionDetail;
//# sourceMappingURL=native-provenance.d.ts.map