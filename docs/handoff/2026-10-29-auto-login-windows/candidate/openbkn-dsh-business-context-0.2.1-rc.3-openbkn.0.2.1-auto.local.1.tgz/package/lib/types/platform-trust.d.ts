import type { CertificateIdentity, PlatformCertificateTrust } from './types.js';
export type { CertificateIdentity, PlatformCertificateTrust } from './types.js';
export type ConnectionFailureCode = 'CERTIFICATE_UNTRUSTED' | 'CERTIFICATE_INVALID' | 'CERTIFICATE_EXPIRED' | 'CERTIFICATE_HOSTNAME_MISMATCH' | 'TRUST_SCOPE_MISMATCH' | 'TRUST_TRANSPORT_UNAVAILABLE' | 'TRUST_CLI_UNAVAILABLE' | 'NETWORK_TIMEOUT' | 'NETWORK_UNREACHABLE' | 'PLATFORM_IDENTITY_CHANGED' | 'PLATFORM_REAUTHORIZATION_REQUIRED' | 'BROWSER_UNAVAILABLE' | 'PLATFORM_REJECTED' | 'CLI_FAILED';
/** Only stable classifications may cross the Host/UI boundary. */
export declare class PlatformConnectionError extends Error {
    readonly code: ConnectionFailureCode;
    constructor(code: ConnectionFailureCode);
}
export declare function platformOrigin(baseUrl: string): string;
/** Accept exactly one bounded certificate, never a key, path or arbitrary file read. */
export declare function inspectPlatformCertificate(baseUrl: string, pem: string, now?: number): CertificateIdentity;
export declare function validatePlatformTrust(baseUrl: string, trust: PlatformCertificateTrust): CertificateIdentity;
/** One business-owner lifetime, no global dispatcher or process.env writes. */
export declare class OpenBknPlatformTrust {
    private readonly baseUrl;
    readonly certificate?: PlatformCertificateTrust | undefined;
    private agent?;
    private readonly lifetime;
    constructor(baseUrl: string, certificate?: PlatformCertificateTrust | undefined);
    readonly fetch: typeof fetch;
    dispose(): Promise<void>;
}
/** Classify bounded CLI output in memory; do not copy it into an Error. */
export declare function connectionFailure(error: unknown): ConnectionFailureCode | undefined;
//# sourceMappingURL=platform-trust.d.ts.map