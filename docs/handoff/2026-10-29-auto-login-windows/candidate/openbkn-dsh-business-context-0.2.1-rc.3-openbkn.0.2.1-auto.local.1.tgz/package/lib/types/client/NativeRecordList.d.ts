import { type ReactNode } from 'react';
/** Page before rendering children. All records remain in the DTO and reachable through controls. */
interface RecordListProps<T> {
    items: readonly T[];
    label: string;
    listId: string;
    contextKey: string;
    pageSize?: number;
    focusKey?: string;
    focusIndex?: number;
    grid?: boolean;
    renderItem: (item: T, index: number) => ReactNode;
}
export declare function NativeRecordList<T>(props: RecordListProps<T>): import("react").JSX.Element;
export {};
//# sourceMappingURL=NativeRecordList.d.ts.map