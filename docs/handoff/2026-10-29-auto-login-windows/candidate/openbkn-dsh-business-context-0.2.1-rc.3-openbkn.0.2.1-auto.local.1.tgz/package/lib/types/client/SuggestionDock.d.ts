import { type OpenBknTranslate } from './messages.ts';
import type { HostObservable, InjectFace, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
export interface SuggestionDockInjected {
    hooks: {
        suggestions: HostObservable<readonly string[]>;
    };
    load(): Promise<void>;
    setDraft(prompt: string): void;
}
export type SuggestionDockProps = PropsRuntime<'conversation.input.dock'> & InjectFace<SuggestionDockInjected>;
/** One bound-network empty-session entry; clicking only fills DSH's native draft. */
export declare function SuggestionDock({ useSuggestions, load, setDraft }: SuggestionDockProps): import("react").JSX.Element | null;
/** The Host emits only this plugin-owned draft template; unknown future prompt text remains verbatim. */
export declare function sessionSuggestionText(prompt: string, t: OpenBknTranslate): string;
//# sourceMappingURL=SuggestionDock.d.ts.map