import { observePlatform, type PlatformPin } from './platform-pin.js';
import type { PlatformAccessRecord, PlatformAccessStore } from './platform-access-profile.js';
/** One existing profile store and one owner lifetime, without changing Host configuration. */
export declare class PrivatePlatformAccess {
    private readonly baseUrl;
    private readonly store;
    private readonly root;
    private readonly observe;
    private checking?;
    private selected?;
    private connection?;
    private disposed;
    private readonly lifetime;
    constructor(baseUrl: string, store: PlatformAccessStore, root: string, observe?: typeof observePlatform);
    inspect(signal?: AbortSignal): Promise<PlatformAccessRecord>;
    private check;
    requireAuthorization(signal?: AbortSignal): Promise<PlatformAccessRecord>;
    authorize(generation: string, signal?: AbortSignal): Promise<void>;
    cliSettings(login: boolean, signal?: AbortSignal): Promise<{
        record: PlatformAccessRecord;
        directory: string;
        pinFile: string;
    }>;
    get certificate(): PlatformPin | {
        automaticPrivateTrust: true;
    };
    readonly fetch: typeof fetch;
    dispose(): Promise<void>;
}
//# sourceMappingURL=private-platform-access.d.ts.map