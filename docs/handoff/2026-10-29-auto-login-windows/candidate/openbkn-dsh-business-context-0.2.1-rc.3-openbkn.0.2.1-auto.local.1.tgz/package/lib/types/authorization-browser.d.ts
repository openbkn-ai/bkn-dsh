import type { CliSubprocess } from './openbkn-cli-subprocess.js';
import type { PlatformPin } from './platform-pin.js';
/** Installed Chromium only; a private user-data directory, never the user's daily browser. */
export declare function openAuthorizationBrowser(subprocess: CliSubprocess, directory: string, pin: PlatformPin, address: string, signal?: AbortSignal): Promise<() => Promise<void>>;
//# sourceMappingURL=authorization-browser.d.ts.map