/** Profile-owned, non-secret platform identity. OAuth tokens remain in the CLI store. */
import { Service, type Context } from '@deepseek-ai/cordis';
import { z } from 'zod';
declare const recordSchema: z.ZodObject<{
    generation: z.ZodString;
    origin: z.ZodString;
    fingerprint256: z.ZodString;
    spki: z.ZodString;
    pem: z.ZodString;
    remoteAddress: z.ZodString;
    authorized: z.ZodBoolean;
    reauthorize: z.ZodOptional<z.ZodBoolean>;
}, z.core.$strip>;
export type PlatformAccessRecord = z.infer<typeof recordSchema>;
export interface PlatformAccessStore {
    get(): PlatformAccessRecord | undefined;
    put(record: PlatformAccessRecord): Promise<void>;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        openbknPlatformAccessProfile: OpenBknPlatformAccessProfile;
    }
}
export declare class OpenBknPlatformAccessProfile extends Service implements PlatformAccessStore {
    static inject: string[];
    private table?;
    constructor(ctx: Context);
    protected [Service.init](): Promise<void>;
    get(): PlatformAccessRecord | undefined;
    put(record: PlatformAccessRecord): Promise<void>;
}
export {};
//# sourceMappingURL=platform-access-profile.d.ts.map