import { type OpenBknMessageKey } from './locales.ts';
export type OpenBknTranslate = (key: OpenBknMessageKey, params?: Record<string, unknown>) => string;
export interface MessageDescriptor {
    readonly key: OpenBknMessageKey;
    readonly params?: Readonly<Record<string, unknown>>;
}
/** State stores a stable key and safe parameters, never a language-specific rendered error. */
export type UiMessage = MessageDescriptor | readonly UiMessage[] | string;
export declare function uiMessage(key: OpenBknMessageKey, params?: Record<string, unknown>): MessageDescriptor;
export declare function joinUiMessages(...messages: UiMessage[]): UiMessage;
export declare function translateMessage(locale: string, key: OpenBknMessageKey, params?: Record<string, unknown>): string;
export declare const translateChinese: OpenBknTranslate;
export declare function renderUiMessage(message: UiMessage | undefined, t?: OpenBknTranslate): string;
//# sourceMappingURL=messages.d.ts.map