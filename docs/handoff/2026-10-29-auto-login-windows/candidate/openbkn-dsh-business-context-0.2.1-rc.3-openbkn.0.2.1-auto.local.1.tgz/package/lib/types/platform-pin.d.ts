import { connect as tlsConnect } from 'node:tls';
import { Agent } from 'undici';
export interface PlatformPin {
    origin: string;
    fingerprint256: string;
    spki: string;
    pem: string;
    remoteAddress: string;
}
/** No HTTP or credential is sent during this bounded, explicitly accepted bootstrap. */
export declare function observePlatform(baseUrl: string, signal?: AbortSignal): Promise<PlatformPin>;
export declare function samePlatformPin(a: PlatformPin, b: PlatformPin): boolean;
/** Private TOFU substitutes an exact observed leaf identity for public CA/name validation. */
export declare function platformPinDispatcher(pin: PlatformPin, connect?: typeof tlsConnect): Agent;
export declare function platformPinFetch(pin: PlatformPin): {
    fetch: typeof fetch;
    dispose(): Promise<void>;
};
//# sourceMappingURL=platform-pin.d.ts.map