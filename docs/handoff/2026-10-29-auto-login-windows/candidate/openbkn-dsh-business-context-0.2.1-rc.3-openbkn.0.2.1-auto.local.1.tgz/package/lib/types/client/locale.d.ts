import { type FunctionComponent } from 'react';
import type { LocaleRuntime } from '@deepseek-ai/dsh-client-locale/client';
import { type OpenBknTranslate } from './messages.ts';
import { type OpenBknMessageKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        openbkn: OpenBknMessageKey;
    }
}
export declare function useOpenBknTranslation(): OpenBknTranslate;
/** One provider per owned slot; locale revisions rerender without replacing controllers or requests. */
export declare function localized<P extends object>(Component: FunctionComponent<P>, locale: LocaleRuntime): FunctionComponent<P>;
//# sourceMappingURL=locale.d.ts.map