import { OpenBknUiController, type OpenBknUiPort, type OpenNetworkSession, type OpenBknConfigurationPort } from './openbkn-ui-controller.ts';
/** Keeps the panel shell usable before, or without, the business services. */
export declare class OpenBknPanelBridge {
    private business?;
    private configuration?;
    readonly controller: OpenBknUiController;
    connect(port: OpenBknUiPort, openNetworkSession: OpenNetworkSession, refreshBoundSession: (sessionId: string) => void): () => void;
    connectConfiguration(port: OpenBknConfigurationPort): () => void;
    private configurationConnection;
    private connection;
}
//# sourceMappingURL=openbkn-panel-bridge.d.ts.map