import type { Context } from '@deepseek-ai/cordis';
import type { Config } from './config.js';
export declare const OPENBKN_MCP_TOKEN_REF = "OPENBKN_MCP_TOKEN";
/**
 * Mounts the standard DSH MCP client once the user has stored an OpenBKN
 * token. It resolves the credential immediately before mounting, and passes it
 * only to the in-memory standard MCP client configuration. An explicitly configured client with the same public tool
 * namespace is treated as the deployment-owned instance.
 */
export declare class OpenBknMcpManager {
    private readonly ctx;
    private readonly config;
    private readonly resolveToken;
    private starting;
    private fiber;
    constructor(ctx: Context, config: Config, resolveToken: () => Promise<string | undefined>);
    private reloading;
    ensure(): Promise<void>;
    private ensureMounted;
    /** Reconnect the client after DSH rotates the managed credential. */
    refresh(): Promise<void>;
    private start;
    private mountFiber;
    /**
     * A rejected MCP handshake surfaces as a protocol error, and DSH then shows
     * the turn as a generic tool-registration failure ("unknown tool") — the G6
     * eval run (docs/evidence/2026-09-23-g6-eval-batch.md) caught the model
     * blaming the plugin instead of the credential. Recognize the
     * authentication/authorization brands inside the cause chain and replace the
     * message with an actionable, credential-only hint. Everything else keeps
     * its original failure shape.
     */
    private explainStartupFailure;
}
/** A known MCP refusal with no upstream cause or credential detail attached. */
export declare class OpenBknMcpCredentialRejectedError extends Error {
    readonly httpStatus: 401 | 403;
    constructor(httpStatus: 401 | 403);
}
/**
 * Resolve the stable Context Loader endpoint from the deployment platform URL.
 * An explicitly configured mcpUrl gets the same scheme fence as the control
 * plane plus an origin fence: the Bearer token mounted on this client may
 * only ever be sent to the configured platform (or an explicitly allowed
 * plaintext loopback), never to an arbitrary host.
 */
export declare function resolveMcpUrl(config: Pick<Config, 'baseUrl' | 'mcpUrl' | 'allowInsecureTls'>): string;
/**
 * Explain one MCP mount failure and record its bounded classification:
 * the stage stays `context-loader` while the transport cause (TLS, timeout)
 * is projected from the cause chain so a certificate problem is not folded
 * into a generic initialization failure.
 * @param error - the rejection from the MCP mount.
 * @returns the caller-facing error (credential hints keep their wording).
 */
export declare function explainMcpStartupFailure(error: unknown): Error;
//# sourceMappingURL=openbkn-mcp-manager.d.ts.map