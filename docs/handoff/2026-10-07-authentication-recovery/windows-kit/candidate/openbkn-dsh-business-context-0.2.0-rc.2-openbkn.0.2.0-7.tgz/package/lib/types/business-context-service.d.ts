import { Context } from '@deepseek-ai/cordis';
import type { Agent } from '@deepseek-ai/dsh-agent';
import type { SessionId } from '@deepseek-ai/dsh-session/types';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import { Config, type Config as PluginConfig } from './config.js';
import { type SessionBindingRecords } from './dsh-session-binding.js';
import { type NetworkCapabilityProfile } from './network-capability-profile.js';
import type { BindBusinessNetworkResult, BusinessNetworkBinding } from './session-binding.js';
import type { AuthSnapshot, BusinessNetworkSummary, ProvenanceHandle, ProvenanceView } from './types.js';
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** Host-owned bridge used by the later OpenBKN client UI to select a business network. */
        openbknBusinessContext: OpenBknBusinessContextService;
    }
}
declare module '@deepseek-ai/dsh-typert-protocol' {
    interface RemoteErrorDetailsMap {
        'openbkn/authentication-required': {
            readonly baseUrl: string;
            readonly layer?: 'context-loader-mcp' | 'platform-api';
            readonly httpStatus?: 401 | 403;
        };
        'openbkn/connection-failed': {
            readonly baseUrl: string;
            readonly layer: 'context-loader-mcp' | 'platform-api';
            readonly httpStatus?: 403;
        };
        'openbkn/platform-unavailable': {
            readonly baseUrl: string;
        };
        'openbkn/cli-unavailable': {
            readonly cliPath: string;
        };
    }
}
/**
 * Owns the only selection transition: durably record the immutable binding in
 * the plugin's own per-session store (never the DSH session log, which hosts
 * without an ignorable-event write path could not reload), then activate the
 * model tool only inside that Agent scope.
 */
export declare class OpenBknBusinessContextService extends TypertRemoteService {
    readonly config: PluginConfig;
    static inject: string[];
    static Config: import("@deepseek-ai/schemastery").default<Config>;
    private readonly mounted;
    private readonly capabilityProfiles;
    private mcpManagerInstance;
    /** Per-session binding records under `$DSH_HOME/openbkn/session-bindings`. */
    bindingRecords: SessionBindingRecords;
    constructor(ctx: Context, config: PluginConfig);
    /**
     * Return the CLI-authenticated state and synchronize its token into the
     * DSH credential vault when needed. The token stays Host-only throughout.
     * A pre-existing manually configured DSH credential remains a fallback for
     * deployments without a usable CLI login.
     */
    remoteStatus(signal: AbortSignal): Promise<AuthSnapshot>;
    /** Start the CLI's configured-platform browser login, then synchronize and verify it. */
    remoteBeginLogin(signal: AbortSignal): Promise<readonly BusinessNetworkSummary[]>;
    /**
     * Save one user-entered token to DSH's credential provider, connect the
     * standard MCP client by reference, then return only visible network DTOs.
     */
    remoteConfigureToken(token: string, signal: AbortSignal): Promise<readonly BusinessNetworkSummary[]>;
    /** Read the immutable network identity already recorded on one live DSH session. */
    remoteGetNetworkBinding(sessionId: SessionId): BusinessNetworkBinding | undefined;
    /** Read only the provenance already committed for one finalized assistant message. */
    remoteGetTurnProvenance(sessionId: SessionId, messageId: string): ProvenanceHandle | undefined;
    /**
     * Resolve the selected turn's provenance on demand through the fixed
     * platform OSDK catalogue. The browser receives a bounded presentation DTO,
     * never raw MCP output, OSDK routes, or credentials.
     *
     * The local timeline (Layer 0) is rebuilt from session events and always
     * renders. Platform reads (Layers 1/2) degrade independently: a failure is
     * classified into `sources.degraded` instead of failing the whole view, so
     * a partially authorized deployment still sees the local execution chain.
     */
    remoteGetTurnProvenanceView(sessionId: SessionId, messageId: string, signal: AbortSignal): Promise<ProvenanceView | undefined>;
    /** Return the one optional, draft-only introduction for an empty bound session. */
    remoteGetSessionSuggestions(sessionId: SessionId): readonly string[];
    /** List only the business networks authorized by the managed OpenBKN token. */
    remoteListNetworks(signal: AbortSignal): Promise<readonly BusinessNetworkSummary[]>;
    /** A successful MCP initial handshake plus OSDK catalogue read is the connection test. */
    private listNetworksAfterAuthentication;
    /** Persist a selected local DSH workspace only after the network is authorized. */
    remoteBindNetworkWorkspace(networkId: string, workspacePath: string, signal: AbortSignal): Promise<BusinessNetworkSummary>;
    /**
     * Bind this exact live Agent to one network already confirmed visible by the
     * configured CLI identity. The Client provides only the opaque network id;
     * display data and platform routing are re-derived on the Host.
     */
    remoteBindNetwork(sessionId: SessionId, networkId: string, signal: AbortSignal): Promise<BusinessNetworkBinding>;
    /**
     * Persist one network selection, reject conflicts, then scope the capability
     * to this Agent. The capability is enabled only after the binding record is
     * durable; a failed write rejects and leaves the session unbound.
     */
    bind(agent: Agent, requested: BusinessNetworkBinding, profile?: NetworkCapabilityProfile): Promise<BindBusinessNetworkResult>;
    private bindingOf;
    /**
     * Global guard: an OpenBKN tool runs only for an Agent carrying the scoped
     * business policy (lifecycle, network scope, PTC refusal). Unbound sessions,
     * sessions whose binding could not be read or conflicted when restored,
     * sessions bound to another platform, and fresh sub-agents are refused. The
     * check is the mounted policy, not a re-read of the record, so a record that
     * breaks after mounting takes effect when the session is reopened.
     */
    private openBknToolDenial;
    private mountIfBound;
    /**
     * Bring a newly live session's binding into effect: its own record or log
     * event, a fork's inherited binding, or a unique workspace association. A
     * failure leaves the session unbound (no OpenBKN capability) and is logged;
     * it never blocks the native DSH session.
     */
    private restoreBinding;
    /**
     * The binding as a native-session lifecycle hook sees it: an unreadable,
     * malformed, or conflicting binding counts as unbound (and is logged), the
     * same outcome `restoreBinding` gave the session, so the OpenBKN capability
     * stays off but native DSH turns keep running. Remote reads still surface
     * the error to the UI through `bindingOf`.
     */
    private bindingOrUnbound;
    /** Remove binding records of sessions DSH no longer stores; see `SessionBindingStore.pruneOrphans`. */
    private pruneOrphanBindings;
    private warnBindingUnavailable;
    /**
     * Project one user-approved workspace association into a newly live native
     * DSH session. A missing or ambiguous association deliberately leaves the
     * native session untouched.
     */
    private bindWorkspaceNetworkIfUnique;
    /**
     * Reconcile the CLI-owned credential before a bound business turn reaches
     * its first model step. This is the only per-turn lifecycle point: later
     * tool-planning steps retain the same connection and do not re-authenticate.
     */
    private refreshManagedMcpAtTurnStart;
    private ensureMcpConnection;
    private refreshMcpConnection;
    private mcpManager;
    private authCoordinator;
    /** Synchronize exactly one configured-platform CLI token into DSH credentials. */
    private synchronizeCliCredential;
    /** Historical private seam retained for unit fixtures; it now returns the Host HTTP reader, never a Python OSDK process. */
    private platformReader;
    /** Resolve only the DSH-managed token; legacy environment variables are not silently migrated. */
    private resolveOpenBknToken;
}
/**
 * Parse the visible-network catalogue and record the list check-point's
 * outcome at the only moment success is knowable: after the parse accepted
 * the payload. A refusal records the response-shape failure on the same
 * subject; reader failures were already attributed by the reader itself.
 * @param payload - raw reader value from the network-list interface.
 * @param decorate - workspace enrichment applied per parsed network.
 * @returns the parsed, decorated network summaries.
 */
export declare function observedNetworkList(payload: unknown, decorate?: (network: BusinessNetworkSummary) => BusinessNetworkSummary): readonly BusinessNetworkSummary[];
//# sourceMappingURL=business-context-service.d.ts.map