import type { BusinessNetworkSummary } from './types.js';
/**
 * Convert one platform response into the bounded data shape consumed by the
 * network selector. The platform remains the authorization authority; this
 * function only removes unneeded fields and rejects malformed rows.
 */
export declare function parseVisibleBusinessNetworks(value: unknown): readonly BusinessNetworkSummary[];
//# sourceMappingURL=business-network-catalog.d.ts.map