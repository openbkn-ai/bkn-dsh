/** The only prompt shown before a bound business session has a completed answer. */
export declare function emptyBusinessSessionPrompt(displayName: string): string;
//# sourceMappingURL=suggested-prompts.d.ts.map