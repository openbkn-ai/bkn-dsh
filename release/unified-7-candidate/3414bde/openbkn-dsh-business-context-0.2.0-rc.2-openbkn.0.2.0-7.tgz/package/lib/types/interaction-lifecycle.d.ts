/**
 * Pure interaction-lifecycle state machine for the noise-reduction design
 * (`docs/plans/2026-09-20-interaction-noise-reduction.md` §6). One instance
 * lives per bound Agent; it is driven only by settled `tools/result` facts
 * (constraint C2: listeners are synchronous, so this module must stay
 * synchronous too) and read by the scoped guard, which stays side-effect free.
 *
 * Two lifetimes are deliberately separated (§5.1): `open` is a per-turn
 * in-memory flag that never survives a turn boundary, while `conversationId`
 * is the cross-turn platform continuity identity whose source of truth is the
 * durable session event log — never model memory. The log's own lifecycle
 * tool results are that source: a restore replays them in log order.
 */
export declare const START_INTERACTION_TOOL = "mcp__openbkn__bkn_start_interaction";
export declare const FINISH_INTERACTION_TOOL = "mcp__openbkn__bkn_finish_interaction";
/**
 * DSH event type earlier plugin releases appended on every conversation
 * change. Nothing writes it any more; `lastConversationEvent` still reads it
 * for diagnostics on existing logs.
 */
export declare const MANAGED_CONVERSATION_EVENT = "openbkn/managed-conversation";
/** The same event after DSH's session-format v3→v4 `plugin:` namespacing of ignorable extensions. */
export declare const MIGRATED_MANAGED_CONVERSATION_EVENT = "plugin:openbkn/managed-conversation";
declare module '@deepseek-ai/dsh-session/types' {
    interface SessionEventMap {
        /** Cross-turn OpenBKN conversation identity held by this DSH session. */
        'openbkn/managed-conversation': ManagedConversationEventData;
    }
}
/**
 * Platform error codes that mean "this conversation_id cannot be continued by
 * the current identity" and therefore justify one controlled `new` retry per
 * turn (§5.3). Verified against OpenBKN EE 0.1.4 — see
 * docs/evidence/dsh-event-model-probe.md §3: `resource_not_disclosed` covers a
 * missing/undisclosed conversation (the 404 cloaking family), and
 * `conversation_owner_mismatch` covers an id owned by another identity.
 * Timeouts, authentication failures, 5xx, and parameter errors are absent on
 * purpose: those must keep the held conversation_id.
 */
export declare const CONVERSATION_INVALID_ERROR_CODES: readonly ["resource_not_disclosed", "conversation_owner_mismatch"];
export interface InteractionLifecycleState {
    /** Whether this turn's Interaction is open; never crosses a turn boundary. */
    readonly open: boolean;
    readonly interactionId?: string;
    /** Cross-turn platform conversation identity; source of truth is the event log. */
    readonly conversationId?: string;
    /** A platform-judged conversation invalidation already happened this turn. */
    readonly conversationInvalidatedThisTurn: boolean;
    readonly startsThisTurn: number;
}
/** The no-payload projection of one settled lifecycle tool result. */
export interface LifecycleToolResultProjection {
    readonly interactionId?: string;
    readonly conversationId?: string;
    readonly errorCode?: string;
}
export interface ManagedConversationEventData {
    readonly conversationId: string;
    readonly status: 'active' | 'invalidated';
    readonly recordedAt: number;
}
/** Minimal event-log shape read by restore. */
export interface SessionEventLike {
    readonly type: string;
    readonly data: unknown;
}
/** A closed turn with no held conversation — the state before any OpenBKN access. */
export declare function initialState(): InteractionLifecycleState;
/**
 * Rebuild the state from a session event log by replaying, in log order, the
 * same transitions the live `tools/result` listener applied: `turn/start`
 * resets the per-turn flags and each logged start/finish result feeds
 * {@link onToolResult}. DSH logs a failed tool as `Error: <message>` with the
 * same `<message>` the live result carried in `error.message`, so the platform
 * error code reads identically. `open` is always false after a restore (the
 * flag never survives a turn boundary). A fork's log holds only its inherited
 * prefix, so it resumes the conversation held at its fork point.
 */
export declare function restoreFrom(events: readonly SessionEventLike[]): InteractionLifecycleState;
/**
 * The last durable conversation event, verbatim — including a closing
 * tombstone. Unlike {@link restoreFrom}, a tombstone is distinguishable from
 * "no event ever existed", which is what a diagnostic reader (has this
 * session's conversation ever been judged invalid?) needs.
 */
export declare function lastConversationEvent(events: readonly SessionEventLike[]): ManagedConversationEventData | undefined;
/** Reset the per-turn flags at `agent/pre-step` (step 1); the conversation id survives. */
export declare function onTurnStart(state: InteractionLifecycleState): InteractionLifecycleState;
/** Classify a failed lifecycle call: only explicit platform invalidation codes count. */
export declare function classifyFailure(payload: LifecycleToolResultProjection): 'conversation-invalid' | 'other';
/** The settled-outcome shape `projectLifecycleOutcome` reads; matches DSH's ToolExecutionResult. */
export interface LifecycleOutcomeLike {
    readonly isError: boolean;
    readonly content?: readonly {
        readonly type?: string;
        readonly text?: string;
    }[];
    readonly error?: {
        readonly message: string;
    };
}
/**
 * No-payload projection of one settled lifecycle result — the single
 * production extraction shared by the plugin, its tests, and the V0 probe.
 * Success: the first JSON record disclosing ids (the platform puts
 * `interaction_id`/`conversation_id` at the top level of lifecycle results).
 * Failure: a bounded parse of the error text for the error-code field only.
 * The platform's envelope nests it as `{"error":{"code":...}}`
 * (agent-retrieval `lifecycleToolErrorWithDetails`), and DSH's MCP client
 * surfaces that text through `error.message`, so both levels are read;
 * anything unparsable classifies as "not determinable" and never clears the
 * held conversation.
 */
export declare function projectLifecycleOutcome(result: LifecycleOutcomeLike): LifecycleToolResultProjection;
/**
 * Fold one settled lifecycle tool result into the state. Only a successful
 * start opens an Interaction; a failed finish keeps it open so the model may
 * retry; every other tool leaves the lifecycle untouched. A platform-judged
 * invalidation also drops the held conversation id from memory — the durable
 * tombstone records it, and keeping a dead id here would have the next turn's
 * prompt and guard both insist on a continuation the platform already refused.
 */
export declare function onToolResult(state: InteractionLifecycleState, name: string, ok: boolean, payload?: LifecycleToolResultProjection): InteractionLifecycleState;
/**
 * The scoped guard's decision for one managed tool call (§6.3 rules 2–5).
 * The caller's catalogue check has already rejected non-managed names (rule
 * 1), so any other name reaching here is a managed in-interaction tool.
 * Returns a model-visible denial with the exact next step, or `undefined` to
 * allow. Rule 2 branches on `startsThisTurn` so a turn that already completed
 * its interaction is told to stop accessing instead of being sent into a
 * start that rules 3–5 would then reject — no deny→retry→deny loops.
 */
export declare function denialFor(state: InteractionLifecycleState, toolName: string, args: Readonly<Record<string, unknown>>): string | undefined;
//# sourceMappingURL=interaction-lifecycle.d.ts.map