import { Service, type Context } from '@deepseek-ai/cordis';
import { z } from 'zod';
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** Durable, non-secret OpenBKN knowledge-network to DSH workspace mapping. */
        openbknWorkspaceBindingRegistry: OpenBknWorkspaceBindingRegistry;
    }
}
/** A local DSH workspace chosen for one OpenBKN business knowledge network. */
export declare const workspaceBindingRecord: z.ZodObject<{
    platformBaseUrl: z.ZodString;
    knowledgeNetworkId: z.ZodString;
    displayName: z.ZodOptional<z.ZodString>;
    workspacePath: z.ZodString;
    updatedAt: z.ZodString;
}, z.core.$strip>;
export type WorkspaceBindingRecord = z.infer<typeof workspaceBindingRecord>;
/** Stable storage key: one configurable OpenBKN platform and network identity. */
export declare function workspaceBindingKey(platformBaseUrl: string, knowledgeNetworkId: string): string;
/**
 * Host-owned durable index for the small, non-secret network-to-workspace
 * association. It deliberately stores a path rather than a DSH workspace id:
 * DSH resolves a registered workspace id from the path at each Client run.
 */
export declare class OpenBknWorkspaceBindingRegistry extends Service {
    static inject: string[];
    private table?;
    constructor(ctx: Context);
    protected [Service.init](): Promise<void>;
    get(platformBaseUrl: string, knowledgeNetworkId: string): WorkspaceBindingRecord | undefined;
    /**
     * Return the one network associated with a native DSH workspace. Ambiguous
     * workspace associations deliberately produce no result so a session is
     * never bound to a network by guesswork.
     */
    findUniqueByWorkspace(platformBaseUrl: string, workspacePath: string): WorkspaceBindingRecord | undefined;
    put(input: Omit<WorkspaceBindingRecord, 'updatedAt'>): Promise<WorkspaceBindingRecord>;
    private requireTable;
}
//# sourceMappingURL=workspace-binding-registry.d.ts.map