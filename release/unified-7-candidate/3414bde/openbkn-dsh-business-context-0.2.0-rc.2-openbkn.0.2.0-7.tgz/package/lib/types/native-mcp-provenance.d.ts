import type { ProvenanceHandle } from './types.js';
interface EventLike {
    readonly type: string;
    readonly data: unknown;
}
export interface NativeMcpTurnProvenance {
    readonly messageId: string;
    readonly handle: ProvenanceHandle;
}
/**
 * Recover provenance only from a completed interaction explicitly returned by
 * the OpenBKN MCP finish call in the same DSH turn. No model text, tool args,
 * or unrelated MCP output participates in this association.
 */
export declare function findCompletedNativeMcpProvenance(events: readonly EventLike[], turn: number): NativeMcpTurnProvenance | undefined;
export {};
//# sourceMappingURL=native-mcp-provenance.d.ts.map