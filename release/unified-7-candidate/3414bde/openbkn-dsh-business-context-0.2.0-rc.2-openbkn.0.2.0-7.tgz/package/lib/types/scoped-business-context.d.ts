import type { Agent } from '@deepseek-ai/dsh-agent';
import type { NetworkCapabilityProfile } from './network-capability-profile.js';
import type { PlatformReaderConfig } from './platform-reader.js';
import type { BusinessNetworkBinding } from './types.js';
declare module '@deepseek-ai/dsh-llm' {
    interface MessageSourceMap {
        'openbkn-answer-fidelity': {
            readonly kind: 'openbkn-answer-fidelity';
            readonly form: 'notice';
            readonly summary: string;
            readonly phase?: 'tool-handoff' | 'final-answer';
        };
    }
}
/** The managed lifecycle pair that brackets any OpenBKN access. */
export declare const LIFECYCLE_TOOLS: readonly ["mcp__openbkn__bkn_start_interaction", "mcp__openbkn__bkn_finish_interaction"];
/**
 * Every other managed OpenBKN tool: schema, skills, capability discovery,
 * queries, metrics, execution, run_code. A turn reaches any of them only
 * inside an open Interaction — reading the network's schema is itself an
 * OpenBKN access. A tool the platform adds stays denied until it is reviewed
 * and listed here or in `EXCLUDED_OPENBKN_TOOLS`; the contract test fails on
 * any Context Loader tool that is in neither.
 */
export declare const MANAGED_IN_INTERACTION_TOOLS: readonly ["mcp__openbkn__get_kn_detail", "mcp__openbkn__search_schema", "mcp__openbkn__get_object_types", "mcp__openbkn__get_relation_types", "mcp__openbkn__query_object_instance", "mcp__openbkn__query_instance_subgraph", "mcp__openbkn__explore_subgraph", "mcp__openbkn__search_instance", "mcp__openbkn__query_metric", "mcp__openbkn__get_logic_properties_values", "mcp__openbkn__run_code", "mcp__openbkn__list_skills", "mcp__openbkn__get_skill_content", "mcp__openbkn__read_skill_file", "mcp__openbkn__search_capabilities", "mcp__openbkn__execute_tool", "mcp__openbkn__execute_skill", "mcp__openbkn__find_skills"];
/**
 * Managed discovery that only the OpenBKN 0.1.4 Context Loader publishes.
 * (`search_tools` existed only between two development commits, #1299 and
 * #1403, and shipped in no release, so it is not managed.)
 */
export declare const LEGACY_DISCOVERY_TOOLS: readonly string[];
/**
 * Context Loader tools reviewed and kept out of a business session: writes
 * (actions), raw query languages and shell, and anything that enumerates or
 * reaches beyond the bound network.
 */
export declare const EXCLUDED_OPENBKN_TOOLS: readonly string[];
/**
 * Denial for a `kn_id` that is missing, not a string, or not the bound
 * network. Which tools take `kn_id` is read from the schema the Context
 * Loader registered (required or optional alike, so the scope is never left
 * to a platform default), not from a list kept here; a `kn_id` argument is
 * checked even when no schema declares it. Tools without `kn_id` — the
 * platform's `run_code`, lifecycle — are not scoped by this check. A call
 * whose definition or input schema cannot be read is refused: its scope
 * would be unknown.
 */
export declare function knScopeDenial(name: string, args: Readonly<Record<string, unknown>>, boundNetworkId: string, definition: unknown): string | undefined;
/**
 * The per-turn injected conversation-continuity text (§5.2). The value comes
 * from durable session events through the lifecycle state, never from model
 * memory; the wording keeps the cross-turn Conversation and this turn's
 * Interaction clearly distinct.
 */
export declare function managedConversationSectionText(conversationId: string | undefined): string;
/**
 * Mount the model-visible OpenBKN tool in one Agent's Cordis scope. An
 * unbound or differently configured session gets no registration at all, so
 * native DSH conversations keep their original tool catalogue.
 */
export declare function mountBoundBusinessNetworkTool(agent: Agent, config: PlatformReaderConfig, binding: BusinessNetworkBinding | undefined, profile?: NetworkCapabilityProfile): boolean;
//# sourceMappingURL=scoped-business-context.d.ts.map