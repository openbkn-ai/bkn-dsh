import type { ProvenanceHandle } from './types.js';
export type { ProvenanceHandle } from './types.js';
/**
 * Validate untrusted session metadata before it becomes a Client-visible
 * provenance reference. Schema v1 events are upgraded in memory to the v2
 * shape (new fields left empty) and are never rewritten to the session log.
 */
export declare function normalizeProvenanceHandle(value: unknown): ProvenanceHandle;
/**
 * Identity comparison for conflict detection. A completed message may not be
 * rewritten to point at a different interaction; the v2 enrichment fields
 * (conversation id, turn, collected request/trace/receipt ids) refine the same
 * turn's record, so a stored v1 event and its v2 re-capture must compare
 * equal instead of raising a conflict.
 */
export declare function sameProvenanceHandle(left: ProvenanceHandle, right: ProvenanceHandle): boolean;
//# sourceMappingURL=provenance-handle.d.ts.map