import type { BusinessNetworkBinding } from './types.js';
export interface NetworkCapabilityProfile {
    readonly schemaVersion: 1;
    readonly profileVersion: string;
    readonly knowledgeNetworkId: string;
    readonly conceptGroups: readonly NamedCapability[];
    readonly objectTypes: readonly NamedCapability[];
    readonly relationTypes: readonly RelationCapability[];
    readonly actionTypes: readonly NamedCapability[];
}
export interface NamedCapability {
    readonly id: string;
    readonly name?: string;
}
export interface RelationCapability {
    readonly id: string;
    readonly sourceObjectTypeId: string;
    readonly targetObjectTypeId: string;
}
/**
 * Project the platform summary into the small, non-instructional index the
 * managed-session policy may expose to an Agent. The original platform payload
 * is deliberately not retained.
 */
export declare function buildNetworkCapabilityProfile(binding: BusinessNetworkBinding, payload: unknown): NetworkCapabilityProfile;
//# sourceMappingURL=network-capability-profile.d.ts.map