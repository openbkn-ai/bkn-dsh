/**
 * Passive, in-process observation buffer shared by the business boundary
 * modules and the diagnostics service.
 *
 * Business code records outcome boundaries (a failed platform request, a CLI
 * refusal, an MCP handshake failure) through {@link passiveDiagnostics};
 * the diagnostics entry reads them back as checks. The module imports no
 * business code, so the dependency direction keeps the diagnostics entry
 * loadable while the business entry is broken — in that state there simply
 * are no observations yet and the fiber-based checks carry the report.
 *
 * Observations are keyed by {@link PassiveObservationInput.subject}: one
 * subject is one checkable point (login state, context loader, platform
 * request, CLI). A success recorded on the same subject supersedes the
 * earlier failure (marked `recovered` with the last failure code kept as
 * evidence), so a stale failure never presents as current after a retry
 * succeeded. Redaction happens at capture time: evidence passes
 * {@link sanitizeDiagnosticsEvidence} before it is stored, so a raw error,
 * message, stack, URL, or credential can never enter the buffer even if a
 * caller passes one by mistake.
 * @module diagnostics-observer
 */
import { type DiagnosticsCheck, type DiagnosticsStage } from './diagnostics-contract.js';
/** Upper bound on distinct observed subjects; further novel keys are dropped. */
export declare const PASSIVE_BUFFER_LIMIT = 20;
/** One recorded outcome boundary. */
export interface PassiveObservationInput {
    /** Stable check-point this outcome belongs to; successes and failures on one subject reconcile. */
    readonly subject: string;
    /** Stage of the newest outcome. */
    readonly stage: DiagnosticsStage;
    /** Classification of the newest outcome (the subject's own name on success). */
    readonly code: string;
    readonly status: 'pass' | 'fail';
    /** Candidate evidence; sanitized at capture, never stored raw. */
    readonly evidence?: Readonly<Record<string, unknown>>;
}
/**
 * Bounded passive outcome buffer keyed by subject. One instance is shared
 * per process via {@link passiveDiagnostics}; tests construct isolated
 * instances.
 */
export declare class PassiveDiagnosticsBuffer {
    private readonly records;
    private droppedSubjects;
    /** Record one outcome; the newest outcome on a subject defines its state. */
    record(input: PassiveObservationInput): void;
    /** Forget everything (tests and explicit resets only). */
    clear(): void;
    /**
     * Project the buffer into passive checks. A subject whose newest outcome
     * is a pass reports `pass` (with `recovered` when a failure preceded it);
     * the report never presents a failure older than the latest retry.
     * @returns checks in first-observed order.
     */
    snapshot(): readonly DiagnosticsCheck[];
    /** How many novel subjects were dropped after the buffer bound was reached. */
    get droppedObservationCount(): number;
}
/** The process-wide passive buffer the business boundaries record into. */
export declare const passiveDiagnostics: PassiveDiagnosticsBuffer;
/** Map a bounded platform HTTP status into evidence, or omit it. */
export declare function httpStatusEvidence(status: unknown): Readonly<Record<string, number>>;
/** Map a bounded CLI exit code into evidence, or omit it. */
export declare function exitCodeEvidence(code: unknown): Readonly<Record<string, number>>;
/**
 * Classify the transport layer of a bounded cause chain: certificate/TLS
 * shapes and timeout brands are recognized without reading message text.
 * Shared by every boundary that dials the platform (reader and MCP mount).
 * The default depth crosses the MCP SDK's wrapper layers (client error →
 * transport error → undici TypeError → socket code).
 * The generic `transport` marker names the network layer without guessing a
 * cause: the MCP SDK's SdkError truncates the undici chain to a plain
 * "fetch failed", so a certificate problem on that route is not
 * distinguishable from DNS or a refused connection (a recorded limitation).
 * @param cause - the error chain to classify (marker fields only).
 * @param depth - maximum cause-chain depth walked.
 * @returns which transport markers the chain carries.
 */
export declare function transportMarkersOf(cause: unknown, depth?: number): {
    tls: boolean;
    timeout: boolean;
    transport: boolean;
};
//# sourceMappingURL=diagnostics-observer.d.ts.map