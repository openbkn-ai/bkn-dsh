import type { ProvenanceBusinessElement, ProvenanceBusinessOperation, ProvenanceContextRelation } from './types.js';
export interface BusinessGraphNode {
    readonly key: string;
    readonly element: ProvenanceBusinessElement;
    readonly operation: ProvenanceBusinessOperation;
    readonly x: number;
    readonly y: number;
}
export interface BusinessGraphEdge {
    readonly id: string;
    readonly name: string;
    readonly sourceKey: string;
    readonly targetKey: string;
    readonly source: BusinessGraphNode;
    readonly target: BusinessGraphNode;
}
export interface BusinessGraphModel {
    readonly nodes: readonly BusinessGraphNode[];
    readonly edges: readonly BusinessGraphEdge[];
    /** Formal relations whose endpoints were not disclosed as resolved objects. */
    readonly unresolvedRelations: readonly ProvenanceContextRelation[];
    readonly width: number;
    readonly height: number;
}
/**
 * Builds a deterministic display model from the Enterprise projection only.
 * Missing relation endpoints stay unresolved; the client never invents nodes.
 */
export declare function buildBusinessGraphModel(operations: readonly ProvenanceBusinessOperation[], relations: readonly ProvenanceContextRelation[]): BusinessGraphModel;
export declare const businessGraphGeometry: {
    readonly nodeWidth: 180;
    readonly nodeHeight: 86;
};
//# sourceMappingURL=business-graph-model.d.ts.map