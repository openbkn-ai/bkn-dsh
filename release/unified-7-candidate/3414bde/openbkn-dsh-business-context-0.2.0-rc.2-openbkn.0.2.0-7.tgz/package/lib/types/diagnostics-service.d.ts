/**
 * Host-side diagnostics service exposed as the `openbknDiagnostics` Remote
 * namespace.
 *
 * The service owns no business state and imports no business module, so the
 * business entry failing (config validation, module resolution, startup)
 * cannot take the report channel down. Reports are assembled strictly from
 * the public loader/fiber surface ({@link diagnostics-host-adapter}) and
 * whitelisted scalars ({@link diagnostics-contract}); raw errors are
 * classified in this module and never leave the Host.
 * @module diagnostics-service
 */
import { Context } from '@deepseek-ai/cordis';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import { type DiagnosticsReport } from './diagnostics-contract.js';
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** Passive OpenBKN diagnostics available even when the business entry failed. */
        openbknDiagnostics: OpenBknDiagnosticsService;
    }
}
/**
 * Diagnostics service: passive report assembly over the public loader
 * surface. D1 adds the observed-operation collectors and the bounded active
 * retest; nothing here may assume the business entry is loaded.
 */
export declare class OpenBknDiagnosticsService extends TypertRemoteService {
    static inject: string[];
    constructor(ctx: Context);
    /**
     * Assemble one passive diagnostics report: entry/fiber state plus the
     * bounded observations recorded by the business boundaries (empty when the
     * business entry never loaded — the fiber checks carry that case).
     * @param signal - cancellation signal from the Remote transport; optional
     * because the client may invoke without one.
     * @returns the whitelisted report DTO.
     */
    getReport(signal?: AbortSignal): Promise<DiagnosticsReport>;
}
//# sourceMappingURL=diagnostics-service.d.ts.map