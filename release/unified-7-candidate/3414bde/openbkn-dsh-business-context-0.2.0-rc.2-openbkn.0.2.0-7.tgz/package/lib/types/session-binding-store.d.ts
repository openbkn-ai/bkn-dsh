import type { BusinessNetworkBinding } from './types.js';
/**
 * One DSH session's immutable OpenBKN binding, kept outside the session log.
 *
 * DSH hosts without a write path for ignorable plugin session events (the
 * official desktop app, stock source builds) refuse to reload a log that holds
 * a plugin-owned event, so the binding lives in one plugin-owned file per
 * session instead. DSH's per-session cross-process write lease means only the
 * host that has the session live ever writes that session's file.
 */
export interface SessionBindingRecord {
    readonly schemaVersion: 1;
    readonly sessionId: string;
    readonly binding: BusinessNetworkBinding;
    /**
     * Session log length when the binding was written. A fork inherits the
     * binding only when its copied prefix reaches this point.
     */
    readonly boundAtSeq: number;
    readonly recordedAt: string;
}
/** File-per-session binding records under one plugin-owned directory. */
export declare class SessionBindingStore {
    readonly root: string;
    constructor(root: string);
    /**
     * Read one session's record synchronously (callers sit on DSH's synchronous
     * turn and guard paths). A missing file is "not bound"; anything unreadable
     * or malformed fails closed with the file path.
     */
    read(sessionId: string): SessionBindingRecord | undefined;
    /**
     * Durably write one record: a synced temporary file renamed over the target,
     * so a crash leaves either the previous state or the complete record.
     * Resolves only after the rename; a rejection means nothing new is readable.
     */
    write(record: SessionBindingRecord): Promise<void>;
    /**
     * Remove records whose session DSH no longer stores. DSH has no session
     * delete verb, so a record only outlives its session when the log was
     * removed outside DSH. Sessions materialize lazily and an unmaterialized
     * one is visible only to the process that created it, so a record is
     * removed only when it is older than `recordedBefore` and `exists` answers
     * false; a malformed record or a failing `exists` is left alone.
     * @returns the session ids whose records were removed.
     */
    pruneOrphans(exists: (sessionId: string) => Promise<boolean>, recordedBefore: Date): Promise<string[]>;
    private pathFor;
}
//# sourceMappingURL=session-binding-store.d.ts.map