/**
 * Readers for a DSH `tool/result` session message across both logged shapes.
 *
 * Session format v4 (DSH 0.2.x) stores a tool message as
 * `{ role: 'tool', toolCallId, isError, content: [{ type: 'text', text }] }`.
 * Earlier formats wrapped the payload as
 * `{ content: [{ type: 'tool-result', isError?, content: [{ type: 'text', text }] }] }`.
 * Logs of either generation stay readable, so both are accepted.
 */
/** Every text payload of one tool message, in logged order. */
export declare function toolResultTexts(message: Record<string, unknown> | undefined): string[];
/** Whether the tool message records a failed call (v4 message flag or a legacy block flag). */
export declare function toolResultIsError(message: Record<string, unknown> | undefined): boolean;
//# sourceMappingURL=tool-result-message.d.ts.map