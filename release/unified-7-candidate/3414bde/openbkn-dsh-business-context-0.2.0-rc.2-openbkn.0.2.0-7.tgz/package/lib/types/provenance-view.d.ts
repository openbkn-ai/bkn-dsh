import type { ProvenanceDegradation, ProvenanceHandle, ProvenanceTimelineNode, ProvenanceView } from './types.js';
export interface ProvenanceViewLimits {
    readonly maxGraphNodes: number;
    readonly maxGraphEdges: number;
}
/** Platform read failures the service already classified, keyed by pane. */
export interface ProvenanceViewDegradations {
    readonly operations?: ProvenanceDegradation;
    readonly business?: ProvenanceDegradation;
}
/**
 * Assemble the layered provenance view: the local timeline (Layer 0) always
 * renders, while platform facts (Layer 1) and the enterprise projection
 * (Layer 2) only refine their own panes. It never derives BKN mappings from
 * raw Core or MCP payloads, and never blocks one layer behind another.
 */
export declare function buildProvenanceView(handle: ProvenanceHandle, timeline: readonly ProvenanceTimelineNode[], operationsResponse: unknown | undefined, enterpriseProjection: unknown | undefined, degradations: ProvenanceViewDegradations, limits: ProvenanceViewLimits): ProvenanceView;
//# sourceMappingURL=provenance-view.d.ts.map