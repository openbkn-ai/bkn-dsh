import type { ProvenanceTimelineNode } from './types.js';
interface EventLike {
    readonly type: string;
    readonly time?: number;
    readonly data: unknown;
}
/** How to locate the turn: directly (handle v2) or via its final assistant message (v1). */
export type TurnTimelineLocator = {
    readonly turn: number;
} | {
    readonly messageId: string;
};
/**
 * Rebuild this turn's execution timeline (Layer 0) purely from DSH session
 * events. The timeline is derived at read time and never persisted: the session
 * log already holds every raw fact. Summaries are whitelist projections — no
 * tool argument value and no response-body fragment crosses into a node.
 */
export declare function buildTurnTimeline(events: readonly EventLike[], locator: TurnTimelineLocator): readonly ProvenanceTimelineNode[];
/** A v1 handle stores no turn; recover it from the turn's final assistant message. */
/** The turn of the last assistant message with this id, if the log holds one. */
export declare function turnForMessage(events: readonly EventLike[], messageId: string): number | undefined;
export { foldTimeline } from './timeline-fold.js';
export type { TimelineFoldGroup } from './timeline-fold.js';
//# sourceMappingURL=turn-timeline.d.ts.map