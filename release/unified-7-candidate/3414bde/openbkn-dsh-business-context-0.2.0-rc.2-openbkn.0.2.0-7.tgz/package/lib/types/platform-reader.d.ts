import type { JsonValue } from '@deepseek-ai/dsh-util-values';
import type { BusinessNetworkBinding } from './session-binding.js';
export type PlatformReaderErrorCode = 'AUTHENTICATION_REQUIRED' | 'LICENSE_REQUIRED' | 'RECORD_NOT_DISCLOSED' | 'PLATFORM_MISMATCH' | 'PLATFORM_UNAVAILABLE' | 'REQUEST_ABORTED' | 'OUTPUT_OVERFLOW' | 'INVALID_RESPONSE';
/** A bounded Host-side error. It never includes platform response bodies. */
export declare class PlatformReaderError extends Error {
    readonly code: PlatformReaderErrorCode;
    /** The platform's own required_action from a permission_denied envelope, truncated. */
    readonly requiredAction?: string;
    /** The bounded HTTP status the caller surfaced, kept for later observation. */
    readonly httpStatus?: number;
    /** The check-point subject this failure was already observed under. */
    observedSubject?: string;
    constructor(code: PlatformReaderErrorCode, message: string, options?: ErrorOptions & {
        readonly requiredAction?: string;
        readonly httpStatus?: number;
    });
    /**
     * Record this failure under the calling method's check-point subject.
     * Idempotent: the first caller wins, so a catch-all never re-records a
     * failure already attributed to a finer-grained subject.
     * @param subject - check-point this failure belongs to.
     * @returns this error, for `throw` chaining.
     */
    observeAs(subject: string): this;
}
export interface PlatformReaderConfig {
    readonly baseUrl: string;
    readonly requestTimeoutMs: number;
    /** Maximum projected payload sent from Host to the DSH browser. */
    readonly maxResultBytes: number;
    readonly allowInsecureTls: boolean;
    /** Business domain header sent on platform requests; defaults to the platform default `bd_public`. */
    readonly businessDomain?: string;
    readonly resolveToken?: () => Promise<string | undefined>;
}
export type PlatformFetch = (input: URL, init: RequestInit) => Promise<Response>;
/**
 * A fixed-route Host reader for plugin control-plane data. It is deliberately
 * separate from the model path: agents use Context Loader MCP; this reader
 * only obtains the catalog, schema profile, and safe Trace projections.
 */
export declare class OpenBknPlatformReader {
    private readonly config;
    private readonly fetcher;
    constructor(config: PlatformReaderConfig, fetcher?: PlatformFetch);
    listKnowledgeNetworks(signal: AbortSignal, _cwd?: string): Promise<JsonValue>;
    getKnowledgeNetworkDetail(binding: BusinessNetworkBinding, signal: AbortSignal, _cwd?: string): Promise<JsonValue>;
    getInteractionOperations(interactionId: string, signal: AbortSignal, _cwd?: string): Promise<JsonValue>;
    getInteractionBusinessGraph(interactionId: string, signal: AbortSignal, _cwd?: string): Promise<JsonValue>;
    /** Resolve the deployment's license edition so license-gated failures can explain themselves. */
    getLicenseEdition(signal: AbortSignal): Promise<{
        edition?: string;
        licensed?: boolean;
    } | undefined>;
    private get;
    private post;
    private request;
    private admit;
}
/** Hosts for which plaintext http is tolerated regardless of the insecure switch. */
export declare function isLoopbackHost(hostname: string): boolean;
/**
 * Scheme fence shared by every outbound OpenBKN path so the Bearer token can
 * never be configured onto a plaintext or unexpected endpoint: https is
 * required outside loopback unless plaintext was explicitly allowed.
 */
export declare function assertHttpsEndpoint(url: URL, allowPlaintext: boolean): void;
//# sourceMappingURL=platform-reader.d.ts.map