import type { ProvenanceTimelineNode } from './types.js';
/** Consecutive tool calls rendered as one row; presentation folds, data does not. */
export interface TimelineFoldGroup {
    readonly nodes: readonly ProvenanceTimelineNode[];
}
/**
 * Fold consecutive same-tool, same-outcome calls into one display group. Nodes
 * carrying `platform` facts never fold — a folded row cannot stand in for
 * several operation ids — and a fold group renders the first node's
 * timestamps. Pure presentation grouping on a client-safe leaf module: the
 * timeline data stays exhaustive.
 */
export declare function foldTimeline(nodes: readonly ProvenanceTimelineNode[]): readonly TimelineFoldGroup[];
//# sourceMappingURL=timeline-fold.d.ts.map