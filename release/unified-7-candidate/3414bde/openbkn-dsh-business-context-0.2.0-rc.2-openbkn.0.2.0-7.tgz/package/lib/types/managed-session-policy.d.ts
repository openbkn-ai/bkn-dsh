import type { NetworkCapabilityProfile } from './network-capability-profile.js';
import type { BusinessNetworkBinding } from './types.js';
export interface ManagedSessionPolicy {
    readonly governance: string;
    readonly capabilities: string;
}
/**
 * Stable lifecycle identity written by OpenBKN Trace for this plugin surface.
 * It is not a user, workspace, model, or knowledge-network identifier.
 */
export declare const OPENBKN_DSH_INTERACTION_AGENT_NAME = "bkn-agent-dsh-business-context";
/** Which capability tools the bound session can actually call; `undefined` while the OpenBKN tools have not registered yet. */
export interface CapabilityToolAvailability {
    readonly searchCapabilities: boolean;
    readonly findSkills: boolean;
    readonly executeTool: boolean;
    readonly executeSkill: boolean;
}
/**
 * The capability routing rule for the tools this deployment registered. The
 * Context Loader catalogue differs by platform release (0.1.5 discovers with
 * search_capabilities, 0.1.4 with find_skills and has no published-function
 * path) and by deployment (execute_skill registers only when the platform
 * enables Skill execution), so the rule names only tools that can be called.
 */
export declare function capabilityRoutingText(available: CapabilityToolAvailability | undefined): string;
/**
 * Produce the two scoped system-prompt sections for one bound network. The
 * fixed section renders the Host-verified identity as quoted data; the optional
 * profile remains a projection rather than a copy of platform metadata.
 */
export declare function buildManagedSessionPolicy(binding: BusinessNetworkBinding, profile?: NetworkCapabilityProfile): ManagedSessionPolicy;
//# sourceMappingURL=managed-session-policy.d.ts.map