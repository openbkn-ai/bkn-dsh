/** A deliberately narrow process boundary around the installed OpenBKN CLI. */
export interface OpenBknCli {
    run(args: readonly string[], signal?: AbortSignal): Promise<CliResult>;
}
/** Process result exposed only inside the Host authentication coordinator. */
export interface CliResult {
    readonly code: number;
    readonly stdout: string;
    readonly stderr: string;
}
import type { AuthSnapshot } from './types.js';
export type { AuthSnapshot } from './types.js';
/** Thrown when the CLI cannot provide a trustworthy authentication status. */
export declare class OpenBknCliError extends Error {
    constructor(message: string);
}
/**
 * Owns authentication lifecycle decisions. OpenBKN CLI remains the credential
 * store and refresh authority. Its token value is read only after an exact
 * platform fence and is returned only to Host-side credential synchronization.
 */
export declare class AuthCoordinator {
    private readonly cli;
    private readonly baseUrl;
    constructor(cli: OpenBknCli, baseUrl: string);
    /** Read the active CLI session and fence it to this plugin's configured platform. */
    status(signal?: AbortSignal): Promise<AuthSnapshot>;
    /**
     * Ask the CLI to initiate its normal local-browser OAuth flow. The plugin
     * deliberately does not use `--no-browser`: that variant requires a human
     * to paste an OAuth callback into stdin, while DSH's managed subprocess has
     * no terminal input surface. Its human-facing output is not persisted here.
     */
    beginLogin(): Promise<void>;
    /**
     * Read one refreshed token for the configured, authenticated platform.
     * Callers must immediately write it to DSH credentials and must never expose
     * this value through a Remote result, UI state, diagnostics, or logs.
     */
    readToken(signal?: AbortSignal): Promise<string>;
}
//# sourceMappingURL=auth.d.ts.map