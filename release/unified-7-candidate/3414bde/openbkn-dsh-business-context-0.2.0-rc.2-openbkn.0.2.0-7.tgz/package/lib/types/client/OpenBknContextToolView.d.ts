import type { ToolCallViewProps } from '@deepseek-ai/dsh-client-ui-tool/client';
/** Safe replacement for the generic raw-output row of the fixed OpenBKN context tool. */
export declare function OpenBknContextToolView({ block }: ToolCallViewProps): import("react").JSX.Element;
//# sourceMappingURL=OpenBknContextToolView.d.ts.map