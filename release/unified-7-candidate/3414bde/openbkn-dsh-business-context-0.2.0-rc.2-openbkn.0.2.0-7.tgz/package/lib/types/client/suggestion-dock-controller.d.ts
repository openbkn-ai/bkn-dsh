import type { HostObservable } from '@deepseek-ai/dsh-client-ui-slots';
/** Per-session, browser-local cache of the Host-resolved empty-session entry. */
export declare class SuggestionDockController implements HostObservable<readonly string[]> {
    private readonly read;
    private prompts;
    private readonly listeners;
    private revision;
    constructor(read: () => Promise<readonly string[]>);
    getSnapshot: () => readonly string[];
    subscribe: (listener: () => void) => (() => void);
    load(): Promise<void>;
    /** Hide the entry as soon as the native DSH turn starts. */
    beginTurn(): void;
    /** Reload after a session binding is established. */
    refresh(): Promise<void>;
    private publish;
}
/** The entry is relevant only before the first native DSH turn. */
export declare function synchronizeSuggestionDockForEvents(controller: Pick<SuggestionDockController, 'beginTurn' | 'refresh'>, events: readonly {
    readonly type: string;
}[]): void;
//# sourceMappingURL=suggestion-dock-controller.d.ts.map