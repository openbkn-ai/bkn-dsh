import type { BusinessNetworkSummary } from '../types.ts';
export declare const INITIAL_NETWORK_DIRECTORY_LIMIT = 20;
export interface NetworkDirectorySelection {
    readonly networks: readonly BusinessNetworkSummary[];
    readonly total: number;
    readonly hasMore: boolean;
}
/**
 * Pure browser-side presentation over the already-authorized catalogue. It
 * neither broadens visibility nor changes the stable Host catalogue itself.
 */
export declare function selectNetworkDirectory(networks: readonly BusinessNetworkSummary[], query: string, limit?: number): NetworkDirectorySelection;
//# sourceMappingURL=network-directory.d.ts.map