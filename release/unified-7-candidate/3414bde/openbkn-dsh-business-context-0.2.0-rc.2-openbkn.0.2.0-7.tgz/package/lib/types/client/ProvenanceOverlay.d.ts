import type { HostObservable, InjectFace, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { ProvenanceHandle, ProvenanceView } from '../types.ts';
export interface ProvenanceOverlayState {
    readonly sessionId?: string;
    readonly messageId?: string;
    readonly handle?: ProvenanceHandle;
}
interface FocusTarget {
    focus(): void;
}
/** Global overlay state remains outside the transcript and its native scroll container. */
export declare class ProvenanceOverlayController implements HostObservable<ProvenanceOverlayState> {
    private state;
    private readonly listeners;
    private restoreFocus;
    getSnapshot: () => ProvenanceOverlayState;
    subscribe: (listener: () => void) => (() => void);
    open(sessionId: string, messageId: string, handle: ProvenanceHandle, restoreFocus?: FocusTarget): void;
    close(): void;
    private publish;
}
export interface ProvenanceOverlayInjected {
    hooks: {
        provenanceOverlay: ProvenanceOverlayController;
    };
    load(sessionId: string, messageId: string): Promise<ProvenanceView | undefined>;
    close(): void;
}
export type ProvenanceOverlayProps = PropsRuntime<'shell.overlay'> & InjectFace<ProvenanceOverlayInjected>;
/** Provenance detail lives in an additive shell overlay, never inline in DSH chat. */
export declare function ProvenanceOverlay({ useProvenanceOverlay, load, close }: ProvenanceOverlayProps): import("react").JSX.Element | null;
export {};
//# sourceMappingURL=ProvenanceOverlay.d.ts.map