import type { DiagnosticsReport } from '../diagnostics-contract.ts';
/** Serializer indirection so tests can capture downloads without a DOM. */
export interface DownloadPort {
    download(fileName: string, contents: string): void;
}
/**
 * Build the export file name for one report: UTC timestamp plus the short
 * report id, so two exports from one panel are distinguishable.
 * @param report - the report being exported.
 * @returns a file-system-safe JSON file name.
 */
export declare function diagnosticsExportFileName(report: Pick<DiagnosticsReport, 'createdAt' | 'reportId'>): string;
/**
 * Serialize a report for export. The DTO is whitelisted by construction; this
 * re-stringifies deterministically and refuses non-JSON leftovers.
 * @param report - the report to export.
 * @returns the JSON document text.
 */
export declare function serializeDiagnosticsReport(report: DiagnosticsReport): string;
/**
 * Export one report as a JSON download.
 * @param report - the report to export.
 * @param port - download sink (browser file save by default).
 */
export declare function exportDiagnosticsReport(report: DiagnosticsReport, port?: DownloadPort): void;
//# sourceMappingURL=diagnostics-export.d.ts.map