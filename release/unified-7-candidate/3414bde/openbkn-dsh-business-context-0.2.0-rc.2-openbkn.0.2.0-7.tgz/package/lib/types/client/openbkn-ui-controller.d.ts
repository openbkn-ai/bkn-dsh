import type { AuthSnapshot, BusinessNetworkBinding, BusinessNetworkSummary } from '../types.ts';
/** Minimal browser-safe port over the generated OpenBKN Remote contract. */
export interface OpenBknUiPort {
    status(signal?: AbortSignal): Promise<AuthSnapshot>;
    beginLogin(signal?: AbortSignal): Promise<readonly BusinessNetworkSummary[]>;
    configureToken(token: string, signal?: AbortSignal): Promise<readonly BusinessNetworkSummary[]>;
    listNetworks(signal?: AbortSignal): Promise<readonly BusinessNetworkSummary[]>;
    bindNetworkWorkspace(networkId: string, workspacePath: string, signal?: AbortSignal): Promise<BusinessNetworkSummary>;
    bindNetwork(sessionId: string, networkId: string, signal?: AbortSignal): Promise<BusinessNetworkBinding>;
}
export type NetworkSessionMode = 'continue' | 'new' | 'create-workspace';
export type OpenNetworkSession = (network: BusinessNetworkSummary, mode: NetworkSessionMode) => Promise<string>;
export type OpenBknOverlayPhase = 'idle' | 'loading' | 'authentication-required' | 'ready' | 'binding' | 'error';
/** Render state for the additive OpenBKN overlay; credentials never enter it. */
export interface OpenBknOverlayState {
    readonly open: boolean;
    readonly phase: OpenBknOverlayPhase;
    readonly auth?: AuthSnapshot;
    readonly networks: readonly BusinessNetworkSummary[];
    readonly message?: string;
}
type Listener = () => void;
/**
 * Keeps Remote calls and their transient UI state outside React components.
 * The controller intentionally knows only a selected session ID and safe
 * catalogue summaries; Host code remains authoritative for authentication,
 * visibility and durable binding.
 */
export declare class OpenBknUiController {
    private readonly port;
    private readonly openNetworkSession;
    private readonly refreshBoundSession?;
    private state;
    private readonly listeners;
    constructor(port: OpenBknUiPort, openNetworkSession: OpenNetworkSession, refreshBoundSession?: ((sessionId: string) => void) | undefined);
    snapshot(): OpenBknOverlayState;
    /** Slot-renderer observable contract; kept alongside `snapshot()` for tests and callers. */
    getSnapshot(): OpenBknOverlayState;
    subscribe(listener: Listener): () => void;
    open(): void;
    close(): void;
    refresh(signal?: AbortSignal): Promise<void>;
    /** Save and test a token without retaining it in controller state. */
    configureToken(token: string): Promise<void>;
    /** Run the Host-only OpenBKN CLI login, then present its verified catalogue. */
    beginLogin(signal?: AbortSignal): Promise<void>;
    openNetwork(networkId: string, mode: NetworkSessionMode, signal?: AbortSignal): Promise<void>;
    private publish;
}
/**
 * Classify a failed `uiWorkspace.pickDirectory()`. DSH rewraps the Host's
 * `directory-picker/unavailable` refusal into a plain message, so the browse
 * backend (remote/SSH hosts) is recognised by that message; any other failure
 * is the native chooser itself failing and keeps its own text.
 */
export declare function directoryPickerFailure(error: unknown): Error;
/** The operator dismissed the workspace directory chooser. */
export declare function workspaceSelectionCancelled(): Error;
export {};
//# sourceMappingURL=openbkn-ui-controller.d.ts.map