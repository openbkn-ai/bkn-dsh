import type { InjectFace, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { OpenBknUiController } from './openbkn-ui-controller.ts';
export interface OpenBknOverlayInjected {
    hooks: {
        ui: OpenBknUiController;
    };
    close(): void;
    refresh(): Promise<void>;
    beginLogin(): Promise<void>;
    configureToken(token: string): Promise<void>;
    openNetwork(networkId: string, mode: 'continue' | 'new' | 'create-workspace'): Promise<void>;
    openDiagnostics(): void;
}
export type OpenBknOverlayProps = PropsRuntime<'shell.overlay'> & InjectFace<OpenBknOverlayInjected>;
/** Frame-wide, additive OpenBKN control plane. It is intentionally outside DSH chat scroll containers. */
export declare function OpenBknOverlay({ useUi, close, refresh, beginLogin, configureToken, openNetwork, openDiagnostics }: OpenBknOverlayProps): import("react").JSX.Element | null;
//# sourceMappingURL=OpenBknOverlay.d.ts.map