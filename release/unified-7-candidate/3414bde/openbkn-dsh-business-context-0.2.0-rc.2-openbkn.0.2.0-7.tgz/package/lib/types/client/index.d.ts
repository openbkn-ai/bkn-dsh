import type { Context } from '@deepseek-ai/cordis';
/** Browser-side Cordis identity. */
export declare const name = "openbkn-business-context-client";
/**
 * Reserves an additive browser entry without taking ownership of any DSH
 * shell, conversation, composer, or scrolling surface. Only the base slot and
 * remote services are top-level dependencies: the diagnostics segment must
 * register even while session/workspace services are still starting (or
 * never start), and the business segment waits for its own services below.
 */
export declare const inject: string[];
/**
 * Mount the generated Remote boundary, then register two independent
 * segments: the panel shell and diagnostics first (they must never wait for
 * business services), and the business slots after.
 */
export declare function apply(ctx: Context): Promise<() => Promise<void>>;
//# sourceMappingURL=index.d.ts.map