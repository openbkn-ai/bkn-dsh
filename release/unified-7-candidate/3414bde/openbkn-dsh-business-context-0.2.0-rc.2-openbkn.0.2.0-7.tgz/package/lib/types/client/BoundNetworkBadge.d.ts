import type { InjectFace, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { BusinessNetworkBinding } from '../types.ts';
export interface BoundNetworkBadgeInjected {
    hooks: {
        binding: BoundNetworkController;
    };
    load(): Promise<void>;
}
export type BoundNetworkBadgeProps = PropsRuntime<'conversation.session.header.actions'> & InjectFace<BoundNetworkBadgeInjected>;
/** Read-only session-header label; changing networks requires a new DSH session. */
export declare function BoundNetworkBadge({ useBinding, load }: BoundNetworkBadgeProps): import("react").JSX.Element | null;
export type BoundNetworkBadgeState = {
    readonly kind: 'idle';
} | {
    readonly kind: 'bound';
    readonly binding: BusinessNetworkBinding;
} | {
    readonly kind: 'absent';
};
/** One Session's safe binding read, expressed in DSH's HostObservable currency. */
export declare class BoundNetworkController {
    private readonly read;
    /** Retry delay for "agent not live yet" reads; injectable for deterministic tests. */
    private readonly retryDelayMs;
    private readonly maxRetries;
    private state;
    private readonly listeners;
    private retries;
    constructor(read: () => Promise<BusinessNetworkBinding | undefined>, 
    /** Retry delay for "agent not live yet" reads; injectable for deterministic tests. */
    retryDelayMs?: number, maxRetries?: number);
    getSnapshot(): BoundNetworkBadgeState;
    subscribe(listener: () => void): () => void;
    load(): Promise<void>;
    private publish;
}
//# sourceMappingURL=BoundNetworkBadge.d.ts.map