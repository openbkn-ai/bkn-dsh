import type { DiagnosticsReport } from '../diagnostics-contract.ts';
/** Minimal browser port over the generated diagnostics Remote contract. */
export interface DiagnosticsUiPort {
    getReport(signal?: AbortSignal): Promise<DiagnosticsReport>;
}
/** Render phases of the diagnostics panel. */
export type DiagnosticsPanelPhase = 'idle' | 'loading' | 'ready' | 'unavailable';
/** Render state for the diagnostics panel; only whitelisted report data enters it. */
export interface DiagnosticsPanelState {
    readonly open: boolean;
    readonly phase: DiagnosticsPanelPhase;
    readonly report?: DiagnosticsReport;
    /** Bounded, non-sensitive note when the diagnostics service itself is unreachable. */
    readonly message?: string;
}
type Listener = () => void;
/**
 * Controller for the diagnostics panel. Registration never waits for the
 * business Remote: the panel is the fallback surface when the business side
 * fails, so it depends on nothing but the diagnostics namespace and the slot
 * registry. D2 adds retest/cancel; the initial slice only reads a report.
 */
export declare class DiagnosticsPanelController {
    private readonly port;
    private state;
    private readonly listeners;
    private loadEpoch;
    constructor(port: DiagnosticsUiPort);
    snapshot(): DiagnosticsPanelState;
    /** Slot-renderer observable contract. */
    getSnapshot(): DiagnosticsPanelState;
    subscribe(listener: Listener): () => void;
    private update;
    open(): void;
    close(): void;
    /** Fetch one passive report; a later open never shows a stale in-flight result. */
    load(): Promise<void>;
    /** Re-read the report on demand. */
    refresh(): Promise<void>;
}
export {};
//# sourceMappingURL=diagnostics-controller.d.ts.map