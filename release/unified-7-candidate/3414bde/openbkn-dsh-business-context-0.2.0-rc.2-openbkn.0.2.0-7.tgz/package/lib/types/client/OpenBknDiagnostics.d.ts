import type { InjectFace, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { DiagnosticsPanelController } from './diagnostics-controller.ts';
export interface OpenBknDiagnosticsInjected {
    hooks: {
        diagnostics: DiagnosticsPanelController;
    };
    open(): void;
    close(): void;
    refresh(): Promise<void>;
}
export type OpenBknDiagnosticsProps = PropsRuntime<'shell.overlay'> & InjectFace<OpenBknDiagnosticsInjected>;
/**
 * Standalone diagnostics surface. Registered by the diagnostics injection
 * segment, never by the business one, so it stays reachable exactly when the
 * business panel is not.
 */
export declare function OpenBknDiagnostics({ useDiagnostics, close, refresh }: OpenBknDiagnosticsProps): import("react").JSX.Element | null;
//# sourceMappingURL=OpenBknDiagnostics.d.ts.map