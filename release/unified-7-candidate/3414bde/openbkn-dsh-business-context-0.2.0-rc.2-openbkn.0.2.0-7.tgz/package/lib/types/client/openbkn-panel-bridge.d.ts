import { OpenBknUiController, type OpenBknUiPort, type OpenNetworkSession } from './openbkn-ui-controller.ts';
/** Keeps the panel shell usable before, or without, the business services. */
export declare class OpenBknPanelBridge {
    private business?;
    readonly controller: OpenBknUiController;
    connect(port: OpenBknUiPort, openNetworkSession: OpenNetworkSession, refreshBoundSession: (sessionId: string) => void): () => void;
    private connection;
}
//# sourceMappingURL=openbkn-panel-bridge.d.ts.map