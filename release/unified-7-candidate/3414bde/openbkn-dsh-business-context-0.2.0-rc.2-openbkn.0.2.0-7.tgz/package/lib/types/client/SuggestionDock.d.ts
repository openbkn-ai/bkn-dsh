import type { HostObservable, InjectFace, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
export interface SuggestionDockInjected {
    hooks: {
        suggestions: HostObservable<readonly string[]>;
    };
    load(): Promise<void>;
    setDraft(prompt: string): void;
}
export type SuggestionDockProps = PropsRuntime<'conversation.input.dock'> & InjectFace<SuggestionDockInjected>;
/** One bound-network empty-session entry; clicking only fills DSH's native draft. */
export declare function SuggestionDock({ useSuggestions, load, setDraft }: SuggestionDockProps): import("react").JSX.Element | null;
//# sourceMappingURL=SuggestionDock.d.ts.map