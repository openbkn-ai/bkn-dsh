import type { HostObservable, InjectFace, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { ProvenanceHandle } from '../types.ts';
export interface TurnProvenanceActionsInjected {
    hooks: {
        provenance: HostObservable<ReadonlyMap<string, ProvenanceHandle>>;
    };
    load(messageId: string): Promise<void>;
    open(messageId: string, handle: ProvenanceHandle, restoreFocus: HTMLElement): void;
}
export type TurnProvenanceActionsProps = PropsRuntime<'conversation.chat.assistant-actions'> & InjectFace<TurnProvenanceActionsInjected>;
/** One compact, native action-row entry for a finalized message with real OpenBKN provenance. */
export declare function TurnProvenanceActions({ messageId, useProvenance, load, open }: TurnProvenanceActionsProps): import("react").JSX.Element | null;
//# sourceMappingURL=TurnProvenanceActions.d.ts.map