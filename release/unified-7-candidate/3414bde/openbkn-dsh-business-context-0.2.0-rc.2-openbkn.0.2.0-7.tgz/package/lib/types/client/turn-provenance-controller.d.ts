import type { HostObservable } from '@deepseek-ai/dsh-client-ui-slots';
import type { ProvenanceHandle } from '../types.ts';
/** Browser-local cache of the Host-committed provenance for finalized assistant messages. */
export declare class TurnProvenanceController implements HostObservable<ReadonlyMap<string, ProvenanceHandle>> {
    private readonly read;
    private view;
    private readonly listeners;
    constructor(read: (messageId: string) => Promise<ProvenanceHandle | undefined>);
    getSnapshot: () => ReadonlyMap<string, ProvenanceHandle>;
    subscribe: (listener: () => void) => (() => void);
    /** Read once per mounted message; a transient failure never erases a committed handle. */
    load(messageId: string): Promise<void>;
}
//# sourceMappingURL=turn-provenance-controller.d.ts.map