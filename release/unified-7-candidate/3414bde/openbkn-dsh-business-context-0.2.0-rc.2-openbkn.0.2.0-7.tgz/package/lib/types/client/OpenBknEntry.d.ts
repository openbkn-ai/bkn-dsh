import type { SessionId } from '@deepseek-ai/dsh-api-remotes/client';
import type { InjectFace, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
export interface OpenBknEntryInjected {
    open(sessionId?: SessionId): void;
}
export type OpenBknEntryProps = PropsRuntime<'sidebar.footer.action'> & InjectFace<OpenBknEntryInjected>;
/** Additive sidebar-footer entry; the native DSH sidebar continues to own its shell. */
export declare function OpenBknEntry({ wide, useSessions, open }: OpenBknEntryProps): import("react").JSX.Element;
//# sourceMappingURL=OpenBknEntry.d.ts.map