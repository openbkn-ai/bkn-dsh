import type { BusinessNetworkBinding } from './types.js';
export type { BusinessNetworkBinding } from './types.js';
/**
 * DSH event type earlier plugin releases appended for the selected business
 * network. New bindings live in the plugin's own binding store; logs that
 * already carry this event stay readable.
 */
export declare const BUSINESS_NETWORK_BOUND_EVENT = "openbkn/business-network-bound";
/**
 * The same event after DSH's session-format v3→v4 migration, which namespaces
 * every unknown ignorable event as `plugin:<type>` while keeping its payload.
 */
export declare const MIGRATED_BUSINESS_NETWORK_BOUND_EVENT = "plugin:openbkn/business-network-bound";
/** Minimal DSH session-log shape needed to restore an OpenBKN binding. */
export interface SessionEventLike {
    readonly type: string;
    readonly data: unknown;
}
/** `bound`: the caller must persist `binding` before using it; `already-bound`: nothing to write. */
export type BindBusinessNetworkResult = {
    readonly kind: 'bound';
    readonly binding: BusinessNetworkBinding;
} | {
    readonly kind: 'already-bound';
    readonly binding: BusinessNetworkBinding;
};
/** A durable session already names a different OpenBKN network or platform. */
export declare class BusinessNetworkBindingConflictError extends Error {
    readonly existing: BusinessNetworkBinding;
    readonly requested: BusinessNetworkBinding;
    constructor(existing: BusinessNetworkBinding, requested: BusinessNetworkBinding);
}
/** Reconstruct the one permitted business-network binding from a DSH event log. */
export declare function readBusinessNetworkBinding(events: readonly SessionEventLike[]): BusinessNetworkBinding | undefined;
/**
 * Decide whether a selection creates the session's one immutable binding.
 * `existing` is the binding already resolved for the session, if any.
 */
export declare function bindBusinessNetwork(existing: BusinessNetworkBinding | undefined, requested: BusinessNetworkBinding): BindBusinessNetworkResult;
/** Validate and normalize one stored binding payload (a log event or a binding record). */
export declare function parseBinding(value: unknown): BusinessNetworkBinding;
/** Two bindings name the same platform and knowledge network (display names may differ). */
export declare function sameIdentity(left: BusinessNetworkBinding, right: BusinessNetworkBinding): boolean;
//# sourceMappingURL=session-binding.d.ts.map