/**
 * Compare a final answer with detail actually returned by this turn's tools.
 * This checks transcription, not the correctness of the platform calculation.
 * Unsupported result formats are not promoted to verified business data.
 */
export interface FidelityEvent {
    readonly type: string;
    readonly data: unknown;
}
export interface DetailRow {
    readonly level: string;
    readonly parent: string;
    readonly child: string;
    readonly name: string;
    readonly usage: string;
    readonly stock: string;
    readonly unit: string;
}
export interface AnswerFidelityIssue {
    readonly code: 'detail-mismatch' | 'source-name-mismatch' | 'detail-count-mismatch' | 'tool-detail-incomplete' | 'detail-handoff-conflict' | 'inventory-scope-mismatch' | 'inventory-semantics-mismatch';
    readonly reason: string;
    readonly correction: string;
}
/** Read explicit columns/level headings only; never infer levels from IDs. */
export declare function detailRowsOf(text: string): readonly DetailRow[];
/** A deterministic transcription of the observed rows, including repetitions. */
export declare function renderDetail(rows: readonly DetailRow[]): string;
/** A narrow producer check, while the original Interaction is still open.
 * Never infer the meaning of headerless positional values. One notice may
 * request a labelled reprint of cached rows, without new business retrieval.
 */
export declare function inspectToolDetailHandoff(events: readonly FidelityEvent[], toolText: string): {
    readonly turn: number;
    readonly issue: AnswerFidelityIssue;
} | undefined;
/**
 * Inspect only this turn, matching tool calls to successful logged outcomes.
 * The final answer is read-only; a caller may steer a correction or fail closed.
 */
export declare function inspectAnswerFidelity(events: readonly FidelityEvent[], turn: number): AnswerFidelityIssue | undefined;
export declare class AnswerFidelityError extends Error {
    readonly code = "answer-fidelity-failed";
    constructor(issue: AnswerFidelityIssue);
}
//# sourceMappingURL=answer-fidelity.d.ts.map