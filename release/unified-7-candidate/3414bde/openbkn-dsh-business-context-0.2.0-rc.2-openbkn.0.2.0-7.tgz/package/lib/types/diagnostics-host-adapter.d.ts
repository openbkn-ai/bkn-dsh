/**
 * Version-locked adapter over the Host Loader's public entry/fiber surface.
 *
 * DSH's own boot audit (`dsh-app-boot` `inactiveEntries`) reads plugin
 * failures through exactly this surface — `entry.fiber`, the public
 * `fiber.state` number, and `fiber.await()`'s documented rethrow of
 * config-validation and startup errors. The adapter mirrors that contract
 * without importing `FiberState`: the published cordis bundle erases the
 * const enum, so a named import of it breaks module resolution on every real
 * Host (verified on dsh 0.2.0-rc.2 during D0). State numbers are pinned to
 * cordis 4.0.4's declaration order (`PENDING=0 … UNLOADING=5`); rejections
 * are classified from the rethrow, and every non-throwing settle is followed
 * by an explicit state read, because `await()` alone also resolves for
 * fibers that never started or were disposed.
 *
 * All types here are structural: this package does not depend on
 * `@deepseek-ai/cordis-plugin-loader`, and any shape drift degrades to
 * `component-unknown-state` / insufficient evidence instead of throwing.
 * @module diagnostics-host-adapter
 */
import type { Context } from '@deepseek-ai/cordis';
/** Upper bound for awaiting one fiber's lifecycle before calling it waiting. */
export declare const FIBER_OBSERVE_TIMEOUT_MS = 1500;
/** The public entry surface the adapter reads. */
export interface LoaderEntryLike {
    readonly options: {
        readonly id: string;
        readonly name: string;
    };
    readonly fiber?: {
        readonly state?: number;
        await(): Promise<unknown>;
    } | undefined;
}
/** The public loader surface the adapter reads. */
export interface LoaderLike {
    entries(): Iterable<LoaderEntryLike>;
}
/** Observed outcome for one plugin entry. */
export type EntryObservation = {
    readonly kind: 'active';
} | {
    readonly kind: 'module-resolution-failed';
} | {
    readonly kind: 'configuration-invalid';
    readonly field: string | null;
} | {
    readonly kind: 'initialization-failed';
} | {
    readonly kind: 'waiting-services';
} | {
    readonly kind: 'unknown-state';
    readonly state: number | undefined;
};
/**
 * Read the loader service from a plugin context without hard-injecting it.
 * The diagnostics entry injects `loader` itself; this helper exists for
 * callers (and tests) that received a context of unknown shape.
 * @param ctx - any Cordis context.
 * @returns the loader when it exposes `entries()`, else undefined.
 */
export declare function loaderOf(ctx: Context): LoaderLike | undefined;
/**
 * Classify a config-validation rejection into a field whitelist hit.
 *
 * Schemastery rejections carry `$`-rooted paths (`$.baseUrl …`) in the
 * message; only field names from the closed {@link BUSINESS_CONFIG_FIELDS}
 * list may surface in evidence. No message text is ever returned.
 * @param error - the rejection recovered from `fiber.await()`.
 * @returns the whitelisted field name, or null when the message names none.
 */
export declare function configurationFieldOf(error: unknown): string | null;
/**
 * Observe one entry through the public fiber lifecycle. `fiber.await()`
 * rethrows the recorded startup rejection of a failed fiber, but resolving
 * alone proves nothing: a fiber that never started (deps missing) or was
 * disposed also resolves, so the settled state is classified explicitly.
 * A bounded timeout reports lifecycle work that never settles as waiting.
 * @param entry - the loader entry to observe.
 * @param timeoutMs - how long to wait for an unsettled lifecycle transition.
 * @returns the classified observation.
 */
export declare function observeEntry(entry: LoaderEntryLike, timeoutMs?: number): Promise<EntryObservation>;
/**
 * Find this package's entries in the loader tree.
 * @param loader - the loader service.
 * @returns the business and diagnostics entries when present, else undefined.
 */
export declare function findOwnEntries(loader: LoaderLike): {
    readonly bootstrap: LoaderEntryLike | undefined;
    readonly business: LoaderEntryLike | undefined;
    readonly diagnostics: LoaderEntryLike | undefined;
};
/** Map an observation to the contract's code table (no message text involved). */
export declare function codeOfObservation(observation: EntryObservation): string;
//# sourceMappingURL=diagnostics-host-adapter.d.ts.map