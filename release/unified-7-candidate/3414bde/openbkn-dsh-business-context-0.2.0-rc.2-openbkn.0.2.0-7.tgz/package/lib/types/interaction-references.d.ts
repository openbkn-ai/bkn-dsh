/** Minimal identifiers explicitly disclosed by an OpenBKN interaction response. */
export interface InteractionReferences {
    readonly interactionId: string;
    /** Operation ids are for execution presentation only; they are never request or Trace ids. */
    readonly operationIds: readonly string[];
}
/**
 * Recover only identifiers that the platform response explicitly labels.
 *
 * In particular, this deliberately does not inspect nested operation payloads:
 * old POC responses may contain arbitrary MCP output, while a future platform
 * contract can add request, Trace, and receipt ids to the provenance handle.
 */
export declare function extractInteractionReferences(value: unknown): InteractionReferences | undefined;
//# sourceMappingURL=interaction-references.d.ts.map