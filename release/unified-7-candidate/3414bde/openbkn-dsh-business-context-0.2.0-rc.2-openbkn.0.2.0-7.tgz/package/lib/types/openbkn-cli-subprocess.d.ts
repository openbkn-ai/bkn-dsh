import type { CliResult, OpenBknCli } from './auth.js';
/** Structural subset of DSH subprocess used for the fixed OpenBKN CLI contract. */
export interface CliSubprocess {
    /**
     * DSH's own executable lookup: absolute paths are checked; bare names are
     * searched on the provider's PATH, with PATHEXT on Windows (`openbkn` →
     * `openbkn.cmd`). `spawn` does neither, so a bare name fails there.
     */
    resolveExecutable(command: string, env?: Readonly<Record<string, string>>, signal?: AbortSignal): Promise<string>;
    spawn(spec: {
        readonly argv: readonly string[];
        readonly cwd: string;
        readonly stdio: {
            readonly stdin: {
                readonly data: string;
            };
            readonly stdout: {
                readonly maxBytes: number;
            };
            readonly stderr: {
                readonly maxBytes: number;
            };
        };
        readonly graceMs: number;
        readonly signal?: AbortSignal;
    }): {
        readonly done: Promise<{
            readonly exitCode: number | null;
        }>;
        readonly collected: {
            readonly stdout?: {
                readFrom(fromByte: number): {
                    readonly text: string;
                    readonly lossy: boolean;
                };
            };
            readonly stderr?: {
                readFrom(fromByte: number): {
                    readonly text: string;
                    readonly lossy: boolean;
                };
            };
        };
    };
}
/** The configured OpenBKN CLI cannot be found or executed by the DSH host. */
export declare class OpenBknCliUnavailableError extends Error {
    readonly cliPath: string;
    constructor(cliPath: string, options?: ErrorOptions);
}
/** DSH-managed invocation of the OpenBKN CLI with a fixed authentication contract. */
export declare class OpenBknCliSubprocess implements OpenBknCli {
    private readonly subprocess;
    private readonly cwd;
    private readonly cliPath;
    private readonly baseUrl;
    constructor(subprocess: CliSubprocess, cwd: string, baseUrl: string, cliPath?: string);
    run(args: readonly string[], signal?: AbortSignal): Promise<CliResult>;
    private resolveArgv;
}
//# sourceMappingURL=openbkn-cli-subprocess.d.ts.map