import Schema from '@deepseek-ai/schemastery';
/** Deployment settings that are safe to keep in a DSH configuration patch. */
export interface Config {
    /** OpenBKN platform base URL; credentials stay exclusively in DSH credentials. */
    baseUrl: string;
    /** Optional Context Loader MCP endpoint; defaults to the standard platform route. */
    mcpUrl?: string;
    /** Optional OpenBKN business domain used to constrain platform requests. */
    businessDomain?: string;
    /** Absolute path to the OpenBKN CLI used only for the Host login/token handshake. */
    cliPath: string;
    /** Upper bound for one OpenBKN request. */
    requestTimeoutMs: number;
    /**
     * Upper bound for one OpenBKN MCP tool call. Raising it only helps a
     * deployment whose gateway allows longer requests: on the measured 0.1.5
     * platform the ingress answers 504 at 60 s and no call succeeded between
     * 20 s and 60 s, so a longer default only made each failure slower.
     */
    toolCallTimeoutMs: number;
    /** Maximum result payload admitted into DSH context. */
    maxResultBytes: number;
    /** Maximum business-context graph node count rendered for one turn. */
    maxGraphNodes: number;
    /** Maximum business-context graph edge count rendered for one turn. */
    maxGraphEdges: number;
    /**
     * Explicit opt-in only; disabled by default for local production use.
     * Allows plaintext http to non-loopback hosts — it does NOT relax TLS
     * certificate validation (self-signed certs are handled by the Node trust
     * store, e.g. NODE_EXTRA_CA_CERTS, not by this switch).
     */
    allowInsecureTls: boolean;
}
/** Runtime schema and conservative defaults for the host plugin row. */
export declare const Config: Schema<Config>;
//# sourceMappingURL=config.d.ts.map