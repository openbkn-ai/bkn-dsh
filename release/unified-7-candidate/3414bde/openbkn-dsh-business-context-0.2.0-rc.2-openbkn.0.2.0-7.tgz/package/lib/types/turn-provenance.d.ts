import type { ProvenanceHandle } from './types.js';
/**
 * Session event earlier plugin releases appended to bind one finalized
 * assistant message to one OpenBKN interaction. Provenance is now re-derived
 * from the log; existing events stay readable and must agree with it.
 */
export declare const TURN_PROVENANCE_EVENT = "openbkn/turn-provenance";
/** The same event after DSH's session-format v3→v4 `plugin:` namespacing of ignorable extensions. */
export declare const MIGRATED_TURN_PROVENANCE_EVENT = "plugin:openbkn/turn-provenance";
export interface TurnProvenanceEvent {
    readonly type: typeof TURN_PROVENANCE_EVENT;
    readonly data: {
        readonly messageId: string;
        readonly handle: ProvenanceHandle;
    };
}
interface SessionEventLike {
    readonly type: string;
    readonly data: unknown;
}
/** A completed message cannot be rewritten to point at a different interaction. */
export declare class TurnProvenanceConflictError extends Error {
    readonly messageId: string;
    constructor(messageId: string);
}
/** Recover the committed handle for exactly one finalized assistant message. */
export declare function readTurnProvenance(events: readonly SessionEventLike[], messageId: string): ProvenanceHandle | undefined;
export {};
//# sourceMappingURL=turn-provenance.d.ts.map